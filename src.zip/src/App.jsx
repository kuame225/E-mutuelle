import React, { useEffect, useState } from "react";
import {
  LogOut, UserCircle2, ArrowLeft, PowerOff, ShieldOff, ShieldCheck, CheckCircle2,
  Users2, GraduationCap, Award, FileBarChart2, WifiOff, AlertTriangle,
} from "lucide-react";
import { AuthProvider, useAuth } from "./AuthContext";
import { supabase } from "./supabaseClient";
import { sauverCache, lireCache, ressembleAUneCoupureReseau } from "./offlineCache";
import { notifierMembre } from "./notifier";
import { C, R, S, SHADOW, PALETTE } from "./theme";

import WelcomeScreen from "./WelcomeScreen";
import LandingPage from "./LandingPage";
import InscriptionOrganisationScreen from "./InscriptionOrganisationScreen";
import DonPubliqueScreen from "./DonPubliqueScreen";
import LoginScreen from "./LoginScreen";
import AdhesionFlow from "./AdhesionFlow";

import MembreDashboard from "./MembreDashboard";
import MembreAides from "./MembreAides";
import MembreProfil from "./MembreProfil";
import MembreBeneficiaires from "./MembreBeneficiaires";
import MembreEpargneAvec from "./MembreEpargneAvec";

import AdminLayout, { ADMIN_PAGES, PAGES_MODULES } from "./AdminLayout";
import TableauBordFinancier from "./TableauBordFinancier";
import AdhesionsPanel from "./AdhesionsPanel";
import MembresPage from "./MembresPage";
import CotisationsPage from "./CotisationsPage";
import TombolaPage from "./TombolaPage";
import ComptabilitePage from "./ComptabilitePage";
import OperationsDiversesPage from "./OperationsDiversesPage";
import BaremePage from "./BaremePage";
import DocumentsPage from "./DocumentsPage";
import ServicesPage from "./ServicesPage";
import FormationsPage from "./FormationsPage";
import PartenairesPage from "./PartenairesPage";
import ActiviteEconomiquePage from "./ActiviteEconomiquePage";
import ProjetsPage from "./ProjetsPage";
import PartageBeneficesPage from "./PartageBeneficesPage";

import MoyensPaiementPage from "./MoyensPaiementPage";
import DeclarationsPaiementPage from "./DeclarationsPaiementPage";
import AgendaPage from "./AgendaPage";
import CommunicationPage from "./CommunicationPage";
import VueEnsemblePage from "./VueEnsemblePage";
import AssembleesPage from "./AssembleesPage";
import TontinePage from "./TontinePage";
import EpargneAvecPage from "./EpargneAvecPage";
import PretsPage from "./PretsPage";
import ParametragePage from "./ParametragePage";
import RapportsPage from "./RapportsPage";
import OffresBaamoPage from "./OffresBaamoPage";
import SuiviPaiementsWave from "./SuiviPaiementsWave";
import AideSupportPage from "./AideSupportPage";
import BeneficiairesAgrPage from "./BeneficiairesAgrPage";
import MembreSupervisionAgr from "./MembreSupervisionAgr";
import DonsPage from "./DonsPage";
import SanctionsPage from "./SanctionsPage";
import SplashScreen from "./SplashScreen";
import ActivationScreen from "./ActivationScreen";
import RecuperationScreen from "./RecuperationScreen";
import PinLockScreen from "./PinLockScreen";
import JournalPage from "./JournalPage";
import RolesPage from "./RolesPage";
import ExploitantConsole from "./ExploitantConsole";
import { consigner, EVENEMENTS } from "./journal";
import { pinEstDefini } from "./pinLock";
import { useParametrage, moduleActif, LOGO_DEFAUT, mesOrganisationsAdministrees, mesOrganisationsMembre, changerOrganisationActive } from "./useParametrage";
import { genererAttestation } from "./AttestationAdhesion";
import { genererHistorique } from "./HistoriqueCotisations";
import { usePermissions } from "./usePermissions";

// Pages de l'espace membre relevant d'un module
const PAGES_MEMBRE_MODULES = {
  tombola: "module_tombola",
  assemblees: "module_assemblees",
  tontine: "module_tontine",
  prets: "module_prets",
  formations: "module_formations",
  services: "module_services",
  partenariats: "module_partenariats",
};

function Shell() {
  const { session, isAdmin, isExploitant, signOut, loading } = useAuth();
  const { params, loading: parametrageEnCours } = useParametrage();
  const { peut, loading: permissionsEnCours } = usePermissions();
  const [page, setPage] = useState("dashboard");
  const [vuePublique, setVuePublique] = useState("accueil");
  const [membre, setMembre] = useState(null);
  const [loadingMembre, setLoadingMembre] = useState(false);
  const [splash, setSplash] = useState(() => !sessionStorage.getItem("splash_vu"));
  const [pinDeverrouille, setPinDeverrouille] = useState(false);
  const [pinEtat, setPinEtat] = useState({ pret: false, configure: false });
  const [espaceAdmin, setEspaceAdmin] = useState(true);
  const [orgActif, setOrgActif] = useState(null); // null = pas encore vérifié
  const [autresOrgsActives, setAutresOrgsActives] = useState([]);
  const [bascule, setBascule] = useState(false);

  const userId = session?.user?.id ?? null;

  // Une organisation en attente de validation (nouvelle inscription) ou
  // suspendue (impayé) ne doit donner accès à rien de l'application —
  // ni à la configuration du PIN, ni au tableau de bord. Vérifié à part de
  // useParametrage (qui lit "parametrage", pas le statut "actif" de
  // l'organisation elle-même) pour ne pas toucher un mécanisme partagé
  // par tout le reste de l'application.
  useEffect(() => {
    if (!session || isExploitant || !params.organisation_id) {
      setOrgActif(null);
      return;
    }
    supabase
      .from("organisations")
      .select("actif")
      .eq("id", params.organisation_id)
      .maybeSingle()
      .then(({ data }) => setOrgActif(data ? data.actif : null));
  }, [session, isExploitant, params.organisation_id]);

  // Un compte peut administrer ou appartenir à plusieurs organisations —
  // si celle actuellement résolue est inactive, on vérifie s'il en a une
  // autre déjà active, pour lui proposer d'y basculer plutôt que de le
  // bloquer sans issue derrière "Espace non actif".
  useEffect(() => {
    if (orgActif !== false) { setAutresOrgsActives([]); return; }

    Promise.all([mesOrganisationsAdministrees(), mesOrganisationsMembre()]).then(
      async ([admin, membre]) => {
        const toutes = [...admin, ...membre].filter(
          (o) => o.organisation_id !== params.organisation_id
        );
        const ids = [...new Set(toutes.map((o) => o.organisation_id))];
        if (ids.length === 0) { setAutresOrgsActives([]); return; }

        const { data } = await supabase
          .from("organisations").select("id, actif").in("id", ids);

        const actives = ids
          .map((id) => {
            const org = toutes.find((o) => o.organisation_id === id);
            const statut = (data || []).find((d) => d.id === id);
            return statut?.actif ? { organisation_id: id, sigle: org.sigle, nom: org.nom } : null;
          })
          .filter(Boolean);

        setAutresOrgsActives(actives);
      }
    );
  }, [orgActif, params.organisation_id]);

  async function basculerVers(id) {
    setBascule(true);
    await changerOrganisationActive(id);
    setBascule(false);
  }

  // Charger la fiche membre. Les administrateurs sont d'abord des adhérents :
  // on charge leur fiche aussi, pour leur permettre de consulter leur espace.
  useEffect(() => {
    if (!session) {
      setMembre(null);
      return;
    }

    // On attend que l'organisation active soit connue : sans elle, la
    // requête filtrerait sur organisation_id = null et manquerait la fiche.
    if (!params.organisation_id) return;

    setLoadingMembre(true);
    supabase
      .from("membres")
      .select("*")
      .eq("user_id", session.user.id)
      .eq("organisation_id", params.organisation_id)
      .maybeSingle()
      .then(({ data }) => {
        setMembre(data || null);
        setLoadingMembre(false);
        if (data && !isAdmin) setPage("accueil");
      });
  }, [session, isAdmin, params.organisation_id]);

  // État du verrouillage, recalculé uniquement au changement de compte
  useEffect(() => {
    if (!userId) {
      setPinEtat({ pret: false, configure: false });
      setPinDeverrouille(false);
      setVuePublique("accueil");
      setEspaceAdmin(true);
      setPage("dashboard");
      return;
    }
    setPinEtat({ pret: true, configure: pinEstDefini(userId) });
    setPinDeverrouille(false);
  }, [userId]);

  // Drapeau posé explicitement par InscriptionOrganisationScreen, plutôt
  // que de parier sur la rapidité de useParametrage : tant qu'il est
  // présent, aucun écran de PIN n'est jamais montré, quelle que soit la
  // vitesse à laquelle l'organisation se résout. Retiré ci-dessous dès
  // que l'état de l'organisation (actif ou non) est connu avec certitude.
  //
  // Calculé et l'effet déclaré ici, avant tout retour anticipé (splash,
  // chargement...) — les placer après une condition de retour, comme la
  // première tentative l'avait fait, viole les règles des Hooks : le
  // nombre de Hooks appelés doit rester identique à chaque rendu, jamais
  // conditionné par un retour précédent (React error #310).
  const venantDInscription = session && !isExploitant
    && sessionStorage.getItem("post_inscription_org") === "1";

  // Approche différente de l'essai précédent : plutôt que de deviner le
  // moment où tout est "stabilisé" en croisant deux signaux qui se
  // résolvent indépendamment (orgActif et loadingMembre, sans ordre
  // garanti), le drapeau reste tant que l'organisation n'est pas
  // RÉELLEMENT active. Tant qu'elle est en attente de validation, chaque
  // affichage de cet écran montre le message de félicitations — combien
  // de fois "Chargement…" repasse entre-temps n'a plus d'importance,
  // il n'y a plus de course à gagner. Le drapeau ne disparaît qu'une
  // fois, le jour où l'exploitant valide réellement l'organisation.
  useEffect(() => {
    if (venantDInscription && orgActif === true) {
      sessionStorage.removeItem("post_inscription_org");
    }
  }, [venantDInscription, orgActif]);

  // Un administrateur ne peut basculer que s'il possède une fiche membre
  const peutBasculer = isAdmin && Boolean(membre);
  const enEspaceMembre = !isAdmin || (peutBasculer && !espaceAdmin);

  function versEspaceMembre() {
    setEspaceAdmin(false);
    setPage("accueil");
  }

  function versEspaceAdmin() {
    setEspaceAdmin(true);
    setPage("dashboard");
  }

  // Page de don publique — reconnue par un paramètre d'URL, jamais par
  // un chemin (?don=SIGLE plutôt que /don/SIGLE), pour ne pas dépendre
  // d'une configuration particulière de Cloudflare Pages pour rediriger
  // les chemins vers l'application. Vérifiée avant tout autre retour
  // anticipé : un lien de don partagé doit s'afficher immédiatement,
  // qu'une session existe ou non dans ce navigateur.
  const donSlug = new URLSearchParams(window.location.search).get("don");
  if (donSlug) {
    return <DonPubliqueScreen slug={donSlug} />;
  }

  // L'écran de démarrage s'efface dès que la session est connue, plutôt
  // qu'au bout d'un délai fixe.
  if (splash) {
    return (
      <SplashScreen
        pret={!loading}
        onDone={() => {
          sessionStorage.setItem("splash_vu", "1");
          setSplash(false);
        }}
      />
    );
  }

  if (loading || loadingMembre) {
    return (
      <div style={ecranAttente}>
        Chargement…
      </div>
    );
  }

  // ---------- Juste après une inscription de mutuelle ----------
  if (venantDInscription && (parametrageEnCours || orgActif === null)) {
    return <div style={ecranAttente}>Chargement…</div>;
  }

  // ---------- Organisation en cours de résolution ----------
  // Le vrai point manqué par le garde-fou précédent : useParametrage()
  // expose un état "loading" propre, jamais lu jusqu'ici par Shell(). Sans
  // ce contrôle, params.organisation_id peut encore valoir null pendant
  // une fraction de seconde après l'ouverture de session (le temps que
  // useParametrage retrouve l'organisation nouvellement créée) — et dans
  // cette fenêtre précise, aucune des conditions ci-dessous ne s'applique
  // encore, laissant passer l'écran de configuration du PIN avant que
  // tout ne se stabilise. Le drapeau ci-dessus couvre déjà le cas d'une
  // inscription fraîche ; ce contrôle reste utile pour toute autre
  // situation où organisation_id tarde à se résoudre.
  if (session && !isExploitant && parametrageEnCours) {
    return <div style={ecranAttente}>Chargement…</div>;
  }

  // ---------- Organisation pas encore active ----------
  // Couvre à la fois une inscription tout juste soumise (en attente de
  // validation par l'exploitant) et une organisation suspendue pour
  // impayé : dans les deux cas, rien d'autre ne doit être accessible —
  // ni la configuration du PIN, ni le tableau de bord. Placé avant les
  // écrans de PIN pour qu'une inscription toute fraîche n'y soit jamais
  // poussée automatiquement. Un état d'attente supplémentaire évite qu'un
  // écran de PIN ne s'affiche brièvement pendant que la vérification est
  // encore en cours (orgActif vaut null tant qu'elle n'a pas répondu).
  if (session && !isExploitant && params.organisation_id && orgActif === null) {
    return <div style={ecranAttente}>Chargement…</div>;
  }

  if (session && !isExploitant && params.organisation_id && orgActif === false) {
    return (
      <div style={ecranAttenteOrg}>
        {venantDInscription
          ? <CheckCircle2 size={32} color={C.success} />
          : <ShieldOff size={32} color={C.textSubtle} />}
        <h1 style={{ fontSize: 19, fontWeight: 700, margin: "14px 0 8px" }}>
          {venantDInscription ? "Félicitations, votre organisation a été créée !" : "Espace non actif"}
        </h1>
        <p style={{ fontSize: 14.5, color: C.textMuted, maxWidth: "36ch", lineHeight: 1.6, margin: 0 }}>
          {venantDInscription
            ? "Votre demande est enregistrée. Notre équipe la valide sous peu et vous préviendra par e-mail dès que votre espace sera actif."
            : "L'espace de votre organisation n'est pas encore actif. Si vous venez de l'inscrire, notre équipe la valide sous peu et vous préviendra. Pour toute question, contactez-nous directement."}
        </p>
        <div
          style={{
            marginTop: 20, display: "flex", alignItems: "flex-start", gap: 10,
            background: PALETTE.blue50, border: `1px solid ${PALETTE.blue100}`,
            borderRadius: 12, padding: "13px 15px", maxWidth: "36ch", textAlign: "left",
          }}
        >
          <ShieldCheck size={16} color={C.primary} style={{ marginTop: 1, flexShrink: 0 }} />
          <p style={{ margin: 0, fontSize: 12.5, lineHeight: 1.55, color: C.textMuted }}>
            <strong style={{ color: C.text }}>L'accès à la plateforme est gratuit</strong> —
            toutes les fonctionnalités de gestion de votre organisation, sans frais
            ni limite de durée. Seules certaines options complémentaires, comme les
            rappels par SMS, sont proposées séparément.
          </p>
        </div>

        {!venantDInscription && autresOrgsActives.length > 0 && (
          <div
            style={{
              marginTop: 18, width: "100%", maxWidth: "36ch",
              display: "flex", flexDirection: "column", gap: 8,
            }}
          >
            <p style={{ margin: "0 0 2px", fontSize: 12.5, color: C.textSubtle }}>
              Vous administrez aussi une organisation active :
            </p>
            {autresOrgsActives.map((o) => (
              <button
                key={o.organisation_id}
                onClick={() => basculerVers(o.organisation_id)}
                disabled={bascule}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                  background: C.primary, color: "#fff", border: "none",
                  borderRadius: 10, padding: "11px 16px", cursor: "pointer",
                  fontFamily: "inherit", fontSize: 13.5, fontWeight: 600,
                }}
              >
                {bascule ? "Changement…" : `Basculer vers ${o.sigle || o.nom}`}
              </button>
            ))}
          </div>
        )}

        <button
          onClick={signOut}
          style={{
            marginTop: 22, display: "flex", alignItems: "center", gap: 8,
            background: "none", border: "none", cursor: "pointer",
            fontFamily: "inherit", fontSize: 13.5, fontWeight: 600, color: C.textMuted,
          }}
        >
          <LogOut size={15} /> Se déconnecter
        </button>
      </div>
    );
  }

  // ---------- Verrouillage par code PIN ----------
  // Retiré comme barrière obligatoire à la demande des utilisateurs —
  // trop de codes en plus du déverrouillage du téléphone lui-même.
  // Conservé uniquement pour les comptes ayant déjà un code (ou une
  // empreinte) configuré avant ce changement, sans jamais en imposer
  // un nouveau : plus personne ne passe par PinSetupScreen.
  if (session && !pinEtat.pret) {
    return <div style={ecranAttente}>Chargement…</div>;
  }

  if (session && pinEtat.configure && !pinDeverrouille) {
    return (
      <PinLockScreen
        userId={session.user.id}
        nomAffiche={membre?.nom}
        onDeverrouille={() => setPinDeverrouille(true)}
      />
    );
  }

  // ---------- Console d'exploitant ----------
  // Un exploitant n'appartient à aucune mutuelle : il ne voit jamais
  // l'espace membre ni l'espace administrateur d'une organisation.
  if (session && isExploitant) {
    return <ExploitantConsole onSignOut={signOut} />;
  }

  // ---------- Parcours public ----------
  if (!session) {
    if (vuePublique === "accueil") {
      // Aucune organisation résolue (visite du domaine nu, sans ?org=) :
      // c'est la page vitrine de la plateforme qui s'affiche, pas
      // WelcomeScreen (qui est propre à une mutuelle précise et resterait
      // vide de contenu tant qu'aucune organisation n'est connue).
      if (!params.organisation_id) {
        return (
          <LandingPage
            onCreationMutuelle={() => setVuePublique("creation_mutuelle")}
            onConnexion={() => setVuePublique("connexion")}
          />
        );
      }

      return (
        <WelcomeScreen
          onLogin={() => setVuePublique("connexion")}
          onAdhesion={() => setVuePublique("adhesion")}
          onActivation={() => setVuePublique("activation")}
          onRecuperation={() => setVuePublique("recuperation")}
          onCreationMutuelle={() => setVuePublique("creation_mutuelle")}
        />
      );
    }

    if (vuePublique === "adhesion") {
      return (
        <div style={{ minHeight: "100vh", background: C.bg, padding: "32px 16px" }}>
          <div style={{ maxWidth: 480, margin: "0 auto" }}>
            <button onClick={() => setVuePublique("accueil")} style={lienRetour}>
              ← Retour à l'accueil
            </button>
            <AdhesionFlow />
          </div>
        </div>
      );
    }

    if (vuePublique === "activation") {
      return <ActivationScreen onBack={() => setVuePublique("accueil")} />;
    }

    if (vuePublique === "recuperation") {
      return (
        <RecuperationScreen
          onBack={() => setVuePublique("accueil")}
          onConnecte={() => window.location.reload()}
        />
      );
    }

    if (vuePublique === "creation_mutuelle") {
      return (
        <InscriptionOrganisationScreen onBack={() => setVuePublique("accueil")} />
      );
    }

    return (
      <LoginScreen
        onAdhesion={() => setVuePublique("adhesion")}
        onBack={() => setVuePublique("accueil")}
      />
    );
  }

  // ---------- Espace membre ----------
  if (enEspaceMembre) {
    if (!membre) {
      return (
        <div style={{ minHeight: "100vh", background: C.bg }}>
          <TopBar
            onSignOut={signOut}
            logo={params.logo_url}
            title={params.nom_mutuelle}
            subtitle="Espace membre"
          />
          <div style={messageAttente}>
            Votre adhésion est en attente de validation par le Bureau.
            Vous recevrez une notification dès qu'elle sera traitée.
          </div>
        </div>
      );
    }

    // Une page dont le module a été désactivé n'est plus accessible, même en
    // conservant l'écran ouvert : on ramène le membre à son accueil.
    const moduleMembre = PAGES_MEMBRE_MODULES[page];
    const pageMembreOuverte = !moduleMembre || moduleActif(params, moduleMembre);

    return (
      <div style={{ minHeight: "100vh", background: C.bg }}>
        {/* Rappel discret pour un membre du Bureau consultant son espace */}
        {peutBasculer && (
          <BandeauBascule onRetour={versEspaceAdmin} />
        )}

        {page !== "accueil" && (
          <TopBar
            onSignOut={signOut}
            logo={params.logo_url}
            title={params.nom_mutuelle}
            subtitle={params.adresse}
          />
        )}

        {!pageMembreOuverte ? (
          <PageMembre onBack={() => setPage("accueil")}>
            <ModuleDesactive />
          </PageMembre>
        ) : (
          <>
            {page === "accueil" && (
              <MembreDashboard membre={membre} onPage={setPage} onSignOut={signOut} />
            )}

            {page === "aides" && (
              <MembreAides membre={membre} onBack={() => setPage("accueil")} />
            )}

            {page === "profil" && (
              <MembreProfil
                membre={membre}
                onBack={() => setPage("accueil")}
                onSignOut={signOut}
              />
            )}

            {page === "beneficiaires" && (
              <MembreBeneficiaires membre={membre} onBack={() => setPage("accueil")} />
            )}

            {page === "epargne_avec" && (
              <MembreEpargneAvec membre={membre} onBack={() => setPage("accueil")} />
            )}

            {page === "supervision_agr" && (
              <MembreSupervisionAgr membre={membre} onBack={() => setPage("accueil")} />
            )}

            {page === "aide_support" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <AideSupportPage membre={membre} />
              </PageMembre>
            )}

            {page === "cotisations" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreCotisations membre={membre} />
              </PageMembre>
            )}

            {page === "documents_membre" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreDocuments membre={membre} />
              </PageMembre>
            )}

            {page === "calendrier_membre" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreCalendrier membre={membre} />
              </PageMembre>
            )}

            {page === "historique_membre" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreHistorique membre={membre} />
              </PageMembre>
            )}

            {page === "formations" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreFormations membre={membre} />
              </PageMembre>
            )}

            {page === "services" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreServices membre={membre} />
              </PageMembre>
            )}

            {page === "partenariats" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembrePartenaires membre={membre} />
              </PageMembre>
            )}

            {page === "tombola" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreTombola membre={membre} />
              </PageMembre>
            )}

            {page === "assemblees" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreAssemblees membre={membre} />
              </PageMembre>
            )}

            {page === "tontine" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembreTontine membre={membre} />
              </PageMembre>
            )}

            {page === "prets" && (
              <PageMembre onBack={() => setPage("accueil")}>
                <MembrePrets membre={membre} />
              </PageMembre>
            )}
          </>
        )}
      </div>
    );
  }

  // ---------- Espace administrateur ----------
  // Masquer une entrée de menu ne suffit pas : la page elle-même doit
  // refuser de s'afficher si son module a été désactivé, ou si la personne
  // n'a pas le rôle qui y donne accès.
  const moduleAdmin = PAGES_MODULES[page];
  const moduleOuvert = !moduleAdmin || moduleActif(params, moduleAdmin);
  const permissionAccordee = permissionsEnCours || peut(page);
  const pageAdminOuverte = moduleOuvert && permissionAccordee;

  return (
    <AdminLayout
      page={page}
      onPage={setPage}
      onSignOut={signOut}
      onEspaceMembre={peutBasculer ? versEspaceMembre : null}
    >
      {!pageAdminOuverte ? (
        <div style={{ padding: 28 }}>
          {!moduleOuvert
            ? <ModuleDesactive administrateur onRetour={() => setPage("dashboard")} />
            : <AccesRefuse onRetour={() => setPage("dashboard")} />}
        </div>
      ) : (
        <>
          {page === "vue_ensemble"  && <VueEnsemblePage onNaviguer={setPage} />}
          {page === "dashboard"     && <TableauBordFinancier />}
          {page === "adhesions"     && <AdhesionsPanel />}
          {page === "membres"       && <MembresPage />}
          {page === "cotisations"   && <CotisationsPage />}
          {page === "moyens_paiement" && <MoyensPaiementPage />}
          {page === "declarations_paiement" && <DeclarationsPaiementPage />}
          {page === "tombola"       && <TombolaPage />}
          {page === "sanctions"     && <SanctionsPage />}
          {page === "aides_admin"   && <AidesAdminPage />}
          {page === "bareme"        && <BaremePage />}
          {page === "documents"     && <DocumentsPage />}
          {page === "services"      && <ServicesPage />}
          {page === "formations"    && <FormationsPage />}
          {page === "partenariats"  && <PartenairesPage />}
          {page === "activite_eco"  && <ActiviteEconomiquePage />}
          {page === "projets"       && <ProjetsPage />}
          {page === "partage_benefices" && <PartageBeneficesPage />}

          {page === "operations"    && <OperationsDiversesPage />}
          {page === "comptabilite"  && <ComptabilitePage />}
          {page === "agenda"        && <AgendaPage />}
          {page === "communication" && <CommunicationPage />}
          {page === "assemblees"    && <AssembleesPage />}
          {page === "tontine"       && <TontinePage />}
          {page === "epargne_avec"  && <EpargneAvecPage />}
          {page === "prets"         && <PretsPage />}
          {page === "parametrage"   && <ParametragePage />}
          {page === "rapports"      && <RapportsPage />}
          {page === "offres_baamo"  && <OffresBaamoPage />}
          {page === "suivi_wave"    && <SuiviPaiementsWave />}
          {page === "aide_support"  && <AideSupportPage />}
          {page === "beneficiaires_agr" && <BeneficiairesAgrPage />}
          {page === "dons"          && <DonsPage />}
          {page === "journal"       && <JournalPage />}
          {page === "roles"         && <RolesPage />}
          {!ADMIN_PAGES.includes(page) && <TableauBordFinancier />}
        </>
      )}
    </AdminLayout>
  );
}

/* ---------------- Module désactivé ---------------- */

function ModuleDesactive({ administrateur, onRetour }) {
  return (
    <div style={carteVide}>
      <PowerOff size={34} color={C.textSubtle} style={{ marginBottom: 12 }} />
      <div style={{ fontSize: 16, fontWeight: 600, color: C.text }}>
        Cette fonction n'est pas activée
      </div>
      <div style={{ marginTop: 8, maxWidth: "44ch", marginInline: "auto" }}>
        {administrateur
          ? "Ce module n'est pas activé pour votre mutuelle. Il peut l'être depuis les paramètres, si vos textes le prévoient."
          : "Cette fonction n'est pas proposée par votre mutuelle."}
      </div>
      {administrateur && onRetour && (
        <button onClick={onRetour} style={{ ...lienRetour, marginTop: 18, justifyContent: "center", width: "100%" }}>
          Revenir au tableau de bord
        </button>
      )}
    </div>
  );
}

/* ---------------- Accès refusé ---------------- */

function AccesRefuse({ onRetour }) {
  return (
    <div style={carteVide}>
      <ShieldOff size={34} color={C.textSubtle} style={{ marginBottom: 12 }} />
      <div style={{ fontSize: 16, fontWeight: 600, color: C.text }}>
        Cet écran ne vous est pas accessible
      </div>
      <div style={{ marginTop: 8, maxWidth: "44ch", marginInline: "auto" }}>
        Votre rôle dans cette mutuelle ne donne pas accès à cette partie de la
        gestion. Rapprochez-vous de l'administrateur si vous pensez qu'il
        s'agit d'une erreur.
      </div>
      {onRetour && (
        <button
          onClick={onRetour}
          style={{ ...lienRetour, marginTop: 18, justifyContent: "center", width: "100%" }}
        >
          Revenir au tableau de bord
        </button>
      )}
    </div>
  );
}

/* ---------------- Bandeau de bascule ---------------- */

function BandeauBascule({ onRetour }) {
  return (
    <>
      <style>{`
        .bascule{
          position:sticky; top:0; z-index:60;
          display:flex; align-items:center; gap:10px;
          background:${C.primary}; color:#fff;
          padding:9px 16px; font-size:13px;
          font-family:'Inter','Poppins',system-ui,sans-serif;
        }
        .bascule-texte{ flex:1; min-width:0; opacity:.92; }
        .bascule-btn{
          display:flex; align-items:center; gap:6px; flex-shrink:0;
          background:rgba(255,255,255,.16); border:1px solid rgba(255,255,255,.28);
          color:#fff; border-radius:8px; padding:7px 12px;
          font-family:inherit; font-size:12.5px; font-weight:600; cursor:pointer;
          transition:background .16s ease;
        }
        .bascule-btn:hover{ background:rgba(255,255,255,.26); }
        @media (max-width:520px){
          .bascule-texte{ font-size:12px; }
        }
      `}</style>

      <div className="bascule">
        <UserCircle2 size={16} />
        <span className="bascule-texte">Vous consultez votre espace personnel</span>
        <button className="bascule-btn" onClick={onRetour}>
          <ArrowLeft size={13} /> Administration
        </button>
      </div>
    </>
  );
}

/* ---------------- Barre supérieure ---------------- */

function TopBar({ onSignOut, logo, title, subtitle }) {
  return (
    <>
      <style>{`
        .topbar{
          position:sticky; top:0; z-index:50;
          background:${C.surface}; border-bottom:1px solid ${C.border};
          padding:12px 20px; display:flex; align-items:center; gap:12px;
          font-family:'Inter','Poppins',system-ui,sans-serif;
        }
        .topbar-logo{ width:38px; height:38px; object-fit:contain; flex-shrink:0; }
        .topbar-text{ flex:1; min-width:0; }
        .topbar-title{
          font-size:15px; font-weight:700; color:${C.primary};
          letter-spacing:-.01em; line-height:1.2;
          white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
        }
        .topbar-sub{
          font-size:12px; color:${C.textSubtle}; line-height:1.3;
          white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
        }
        .topbar-btn{
          display:flex; align-items:center; gap:7px; flex-shrink:0;
          background:transparent; border:1.5px solid ${C.border};
          color:${C.textMuted}; border-radius:10px;
          padding:8px 14px; font-family:inherit; font-size:13.5px;
          font-weight:600; cursor:pointer;
          transition:border-color .18s ease, color .18s ease, background .18s ease;
        }
        .topbar-btn:hover{
          border-color:${C.danger}; color:${C.danger}; background:${C.dangerSoft};
        }
        @media (max-width:520px){
          .topbar-btn span{ display:none; }
          .topbar-btn{ padding:8px 10px; }
        }
      `}</style>

      <header className="topbar">
        <img
          src={logo || LOGO_DEFAUT}
          alt={`Logo ${title}`}
          className="topbar-logo"
          onError={(e) => { e.currentTarget.src = LOGO_DEFAUT; }}
        />
        <div className="topbar-text">
          <div className="topbar-title">{title}</div>
          {subtitle && <div className="topbar-sub">{subtitle}</div>}
        </div>
        <button onClick={onSignOut} className="topbar-btn">
          <LogOut size={15} /> <span>Déconnexion</span>
        </button>
      </header>
    </>
  );
}

/* ---------------- Conteneur de page membre ---------------- */

function PageMembre({ onBack, children }) {
  return (
    <div style={{ padding: "20px 16px", maxWidth: 640, margin: "0 auto" }}>
      <button onClick={onBack} style={lienRetour}>← Retour</button>
      {children}
    </div>
  );
}

/* ---------------- Cotisations du membre ---------------- */

// Petit personnage stylisé, bras levés — vient humaniser la carte de
// statut/régularité. Dessiné en SVG inline (aucune image externe à
// héberger), en camaïeu blanc translucide pour se fondre dans le
// dégradé de la carte plutôt que de trancher dessus.
function MascotteCelebration({ size = 72 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 84 84" fill="none">
      <path d="M28 44 L14 22" stroke="rgba(255,255,255,.85)" strokeWidth="6" strokeLinecap="round" />
      <path d="M56 44 L70 22" stroke="rgba(255,255,255,.85)" strokeWidth="6" strokeLinecap="round" />
      <path d="M30 47 Q42 64 54 47" stroke="rgba(255,255,255,.85)" strokeWidth="6" strokeLinecap="round" fill="none" />
      <circle cx="42" cy="26" r="11" fill="rgba(255,255,255,.95)" />
      <circle cx="38" cy="25" r="1.6" fill={PALETTE.blue800} />
      <circle cx="46" cy="25" r="1.6" fill={PALETTE.blue800} />
      <path d="M37 30q5 4 10 0" stroke={PALETTE.blue800} strokeWidth="2" strokeLinecap="round" fill="none" />
    </svg>
  );
}
const AVATARS_STATUT = {
  F: { a_jour: "/avatars/avatar_femme_a_jour.png", non_a_jour: "/avatars/avatar_femme_non_a_jour.png" },
  M: { a_jour: "/avatars/avatar_homme_a_jour.png", non_a_jour: "/avatars/avatar_homme_non_a_jour.png" },
};

// Avatar illustrant le statut de cotisation du membre — genre + statut
// choisissent l'image parmi les 4 déclinaisons (public/avatars/). Tant
// que le membre n'a pas renseigné son genre, on retombe sur le petit
// personnage neutre en SVG plutôt que d'en deviner un.
function AvatarStatutMembre({ sexe, aJour, hauteur = 96 }) {
  const jeu = AVATARS_STATUT[sexe];
  if (!jeu) return <MascotteCelebration size={60} />;

  return (
    <img
      src={jeu[aJour ? "a_jour" : "non_a_jour"]}
      alt=""
      style={{ height: hauteur, width: "auto", display: "block", flexShrink: 0 }}
    />
  );
}

function MembreCotisations({ membre }) {
  const { params } = useParametrage();
  const [cotisations, setCotisations] = useState([]);
  const [moyens, setMoyens] = useState([]);
  const [declarations, setDeclarations] = useState([]);
  const [waveActif, setWaveActif] = useState(false);
  const [loading, setLoading] = useState(true);
  const [declarationOuverte, setDeclarationOuverte] = useState(null); // cotisation ou tableau de cotisations
  const [waveEnCours, setWaveEnCours] = useState(null); // cotisation.id ou "groupe"
  const [waveErreur, setWaveErreur] = useState("");
  const [selection, setSelection] = useState([]); // ids des cotisations cochées
  const [telechargementHistorique, setTelechargementHistorique] = useState(false);
  const [depuisCache, setDepuisCache] = useState(false);
  const [horodatageCache, setHorodatageCache] = useState(null);
  const [regularite, setRegularite] = useState({ actuelle: 0, record: 0 });

  async function charger() {
    const idCache = `cotisations_${membre.id}`;

    const dejaEnCache = lireCache(idCache);
    if (dejaEnCache) {
      setCotisations(dejaEnCache.donnees.cotisations);
      setMoyens(dejaEnCache.donnees.moyens);
      setDeclarations(dejaEnCache.donnees.declarations);
      setWaveActif(dejaEnCache.donnees.waveActif);
      setLoading(false);
    }

    try {
       const [cotRes, moyRes, declRes, waveRes, regRes] = await Promise.all([
        supabase.from("cotisations").select("*").eq("membre_id", membre.id).order("periode", { ascending: false }),
        supabase.from("moyens_paiement").select("*").eq("organisation_id", membre.organisation_id).eq("actif", true).order("ordre"),
        supabase.from("declarations_paiement").select("cotisation_id, cotisation_ids, statut").eq("membre_id", membre.id).eq("statut", "en_attente"),
        supabase.from("integrations_paiement").select("actif").eq("organisation_id", membre.organisation_id).eq("fournisseur", "wave").maybeSingle(),
        supabase.rpc("calculer_regularite_membre", { p_membre_id: membre.id }),
      ]);

      for (const r of [cotRes, moyRes, declRes, waveRes, regRes]) {
        if (r.error && ressembleAUneCoupureReseau(r.error)) throw r.error;
      }

      const ligneRegularite = regRes.data?.[0] || { regularite_actuelle: 0, record_personnel: 0 };

      const resultat = {
        cotisations: cotRes.data || [], moyens: moyRes.data || [], declarations: declRes.data || [],
        waveActif: Boolean(waveRes.data?.actif),
        regularite: { actuelle: ligneRegularite.regularite_actuelle, record: ligneRegularite.record_personnel },
      };
      sauverCache(idCache, resultat);

      setCotisations(resultat.cotisations);
      setMoyens(resultat.moyens);
      setDeclarations(resultat.declarations);
      setWaveActif(resultat.waveActif);
      setRegularite(resultat.regularite);
      setSelection([]);
      setDepuisCache(false);
      setLoading(false);
    } catch (e) {
      const secours = lireCache(idCache);
      if (secours) {
        setCotisations(secours.donnees.cotisations);
        setMoyens(secours.donnees.moyens);
        setDeclarations(secours.donnees.declarations);
        setWaveActif(secours.donnees.waveActif);
        setRegularite(secours.donnees.regularite || { actuelle: 0, record: 0 });
        setDepuisCache(true);
        setHorodatageCache(secours.horodatage);
      }
      setLoading(false);
    }
  }

  useEffect(() => { charger(); }, [membre.id]);

  // Gratuit — ne recoupe plus un produit payant. Le membre a déjà toutes
  // ces données sous les yeux sur cet écran ; ce bouton n'en produit
  // qu'une version PDF, portable, sans rien à débloquer.
  async function telechargerHistorique() {
    setTelechargementHistorique(true);
    try {
      // Cotisations périodiques uniquement : le document est bâti sur des
      // périodes AAAA-MM, une cotisation exceptionnelle n'y a pas sa place.
      await genererHistorique({
        membre,
        cotisations: cotisations.filter((c) => c.type !== "exceptionnelle"),
        params,
      });
    } catch (e) {
      setWaveErreur("Impossible de générer le document pour le moment.");
    }
    setTelechargementHistorique(false);
  }

  async function payerAvecWave(cotisation) {
    setWaveEnCours(cotisation.id);
    setWaveErreur("");

    const { data, error } = await supabase.functions.invoke("creer-session-wave", {
      body: {
        organisationId: membre.organisation_id,
        cotisationId: cotisation.id,
        origine: window.location.origin,
      },
    });

    if (error || !data?.wave_launch_url) {
      setWaveEnCours(null);
      setWaveErreur(data?.error || "Impossible de démarrer le paiement Wave pour le moment.");
      return;
    }

    window.location.href = data.wave_launch_url;
  }

  // Même principe que payerAvecWave, sur plusieurs cotisations à la
  // fois — voir creer-session-wave, qui accepte désormais cotisationIds
  // en plus de cotisationId.
  async function payerSelectionAvecWave() {
    setWaveEnCours("groupe");
    setWaveErreur("");

    const { data, error } = await supabase.functions.invoke("creer-session-wave", {
      body: {
        organisationId: membre.organisation_id,
        cotisationIds: selection,
        origine: window.location.origin,
      },
    });

    if (error || !data?.wave_launch_url) {
      setWaveEnCours(null);
      setWaveErreur(data?.error || "Impossible de démarrer le paiement Wave pour le moment.");
      return;
    }

    window.location.href = data.wave_launch_url;
  }

  function basculerSelection(id) {
    setSelection((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
  }

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  const declarationEnAttentePour = (cotisationId) =>
    declarations.some((d) => d.cotisation_id === cotisationId || d.cotisation_ids?.includes(cotisationId));

  // Les cotisations exceptionnelles (facultatives) ont leur propre section :
  // elles n'entrent ni dans la frise, ni dans la progression annuelle, ni
  // dans la carte « À régler », ni dans le paiement groupé.
  const periodiques = cotisations.filter((c) => c.type !== "exceptionnelle");
  const exceptionnelles = cotisations.filter((c) => c.type === "exceptionnelle");
  const exceptionnellesImpayees = exceptionnelles.filter(
    (c) => c.statut !== "paye" && !declarationEnAttentePour(c.id)
  );

  const cotisationsImpayees = periodiques.filter((c) => c.statut !== "paye" && !declarationEnAttentePour(c.id));
  const cotisationsSelectionnees = cotisations.filter((c) => selection.includes(c.id));
  const totalSelection = cotisationsSelectionnees.reduce(
    (s, c) => s + ((c.montant_du || 0) - (c.montant_paye || 0)), 0
  );

  // Cotisation à mettre en avant dans la carte d'action prioritaire :
  // la plus ancienne encore impayée (cotisationsImpayees garde l'ordre
  // décroissant de "cotisations", donc le dernier élément est la plus
  // ancienne échéance en souffrance).
  const cotisationPrioritaire = cotisationsImpayees[cotisationsImpayees.length - 1] || null;

  // Progression annuelle — cumul des cotisations de l'année en cours,
  // affiché dans la carte de statut pour donner une vue d'ensemble sans
  // que le membre ait à faire le calcul lui-même.
  const anneeCourante = new Date().getFullYear();
  const cotisationsAnnee = periodiques.filter((c) => c.periode?.startsWith(String(anneeCourante)));
  const totalDuAnnee = cotisationsAnnee.reduce((s, c) => s + (c.montant_du || 0), 0);
  const totalPayeAnnee = cotisationsAnnee.reduce((s, c) => s + (c.montant_paye || 0), 0);
  const pourcentageAnnee = totalDuAnnee > 0 ? Math.round((totalPayeAnnee / totalDuAnnee) * 100) : 0;

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 16 }}>
        <h2 style={{ ...titrePage, marginBottom: 0 }}>Mes cotisations</h2>
        {periodiques.length > 0 && (
          <button
            onClick={telechargerHistorique}
            disabled={telechargementHistorique}
            style={{
              display: "flex", alignItems: "center", gap: 7,
              background: "none", border: `1.5px solid ${C.border}`, color: C.textMuted,
              borderRadius: 8, padding: "8px 14px", cursor: "pointer",
              fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
            }}
          >
            <FileBarChart2 size={15} />
            {telechargementHistorique ? "Génération…" : "Télécharger mon historique"}
          </button>
        )}
      </div>

      {/* ---- Statut de cotisation + régularité + progression annuelle ---- */}
      {periodiques.length > 0 && (
        <div style={{
          position: "relative", overflow: "hidden",
          background: `linear-gradient(135deg, ${PALETTE.blue800}, ${PALETTE.blue600})`,
          color: "#fff", borderRadius: R.xl, padding: 20, marginBottom: 16,
          boxShadow: SHADOW.md,
        }}>
          <div style={{
            position: "absolute", width: 180, height: 180, borderRadius: "50%",
            background: "rgba(255,255,255,.07)", right: -60, top: -70,
          }} />

          <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
            {membre.statut_cotisation === "a_jour"
              ? <CheckCircle2 size={18} color="#A7F3C0" />
              : <AlertTriangle size={18} color="#FDE68A" />}
            <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: ".02em", textTransform: "uppercase" }}>
              {membre.statut_cotisation === "a_jour" ? "À jour" : "En retard"}
            </span>
          </div>

                    <div style={{ position: "relative", display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 12, marginTop: 14, flexWrap: "wrap" }}>
            <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1 }}>
                  {regularite.actuelle} <span style={{ fontSize: 13, fontWeight: 600, opacity: .8 }}>mois</span>
                </div>
                <div style={{ fontSize: 12, opacity: .78, marginTop: 4 }}>Ma régularité</div>
              </div>
              <div>
                <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1 }}>
                  {regularite.record} <span style={{ fontSize: 13, fontWeight: 600, opacity: .8 }}>mois</span>
                </div>
                <div style={{ fontSize: 12, opacity: .78, marginTop: 4 }}>Record personnel</div>
              </div>
            </div>
            <AvatarStatutMembre sexe={membre.sexe} aJour={membre.statut_cotisation === "a_jour"} />
          </div>

          {totalDuAnnee > 0 && (
            <div style={{ position: "relative", marginTop: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, opacity: .85, marginBottom: 6 }}>
                <span>Cotisations {anneeCourante}</span>
                <span>{montant(totalPayeAnnee)} / {montant(totalDuAnnee)} FCFA</span>
              </div>
              <div style={{ height: 8, borderRadius: 999, background: "rgba(255,255,255,.22)", overflow: "hidden" }}>
                <div style={{
                  height: "100%", width: `${Math.min(pourcentageAnnee, 100)}%`,
                  background: "#fff", borderRadius: 999, transition: "width .3s ease",
                }} />
              </div>
              <div style={{ fontSize: 11.5, opacity: .78, marginTop: 4 }}>{pourcentageAnnee}% réglé</div>
            </div>
          )}
        </div>
      )}

      {/* ---- Action prioritaire : la cotisation la plus urgente à régler ---- */}
      {cotisationPrioritaire && (
        <div style={{
          background: C.surface, border: `1.5px solid ${C.primary}`, borderRadius: R.xl,
          padding: 18, marginBottom: 16, display: "flex", alignItems: "center",
          justifyContent: "space-between", flexWrap: "wrap", gap: 12,
          boxShadow: SHADOW.sm,
        }}>
          <div>
            <div style={{ fontSize: 12, color: C.textSubtle, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".02em" }}>
              À régler
            </div>
            <div style={{ fontSize: 16, fontWeight: 700, marginTop: 2 }}>
              {formatPeriode(cotisationPrioritaire.periode)}
            </div>
            <div style={{ fontSize: 13, color: C.textMuted, marginTop: 2 }}>
              {montant((cotisationPrioritaire.montant_du || 0) - (cotisationPrioritaire.montant_paye || 0))} FCFA restants
            </div>
          </div>
          {waveActif ? (
            <button
              onClick={() => payerAvecWave(cotisationPrioritaire)}
              disabled={waveEnCours === cotisationPrioritaire.id}
              style={{
                background: C.primary, border: "none", color: "#fff",
                borderRadius: 10, padding: "12px 22px", cursor: "pointer",
                fontFamily: "inherit", fontSize: 14, fontWeight: 700,
              }}
            >
              {waveEnCours === cotisationPrioritaire.id ? "Redirection…" : "Payer maintenant"}
            </button>
          ) : moyens.length > 0 && (
            <button
              onClick={() => setDeclarationOuverte(cotisationPrioritaire)}
              style={{
                background: C.primary, border: "none", color: "#fff",
                borderRadius: 10, padding: "12px 22px", cursor: "pointer",
                fontFamily: "inherit", fontSize: 14, fontWeight: 700,
              }}
            >
              J'ai payé
            </button>
          )}
        </div>
      )}

      {/* ---- Cotisations exceptionnelles (facultatives) ---- */}
      {exceptionnelles.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, color: C.textSubtle, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".02em", marginBottom: 8 }}>
            Cotisation exceptionnelle
          </div>

          {exceptionnelles.map((c) => {
            const reste = (c.montant_du || 0) - (c.montant_paye || 0);
            const payee = c.statut === "paye";
            const enAttente = declarationEnAttentePour(c.id);

            return (
              <div
                key={c.id}
                style={{
                  background: C.surface, borderRadius: R.xl, padding: 16, marginBottom: 10,
                  border: `1.5px solid ${payee ? C.border : PALETTE.blue100}`, boxShadow: SHADOW.xs,
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 15.5, fontWeight: 700 }}>
                      {c.motif || "Cotisation exceptionnelle"}
                    </div>
                    <div style={{ fontSize: 13, color: C.textMuted, marginTop: 3 }}>
                      {payee ? `${montant(c.montant_du)} FCFA réglés` : `${montant(reste)} FCFA restants`}
                      {!payee && c.date_limite && (
                        <> · avant le {new Date(c.date_limite).toLocaleDateString("fr-FR")}</>
                      )}
                    </div>
                  </div>
                  {payee && <span style={{ ...badge, background: C.successSoft, color: C.success }}>Payé</span>}
                  {c.statut === "partiel" && <span style={{ ...badge, background: C.warningSoft, color: C.warning }}>Partiel</span>}
                </div>

                {!payee && (
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
                    {waveActif && (
                      <button
                        onClick={() => payerAvecWave(c)}
                        disabled={waveEnCours === c.id}
                        style={{
                          background: C.primary, border: "none", color: "#fff",
                          borderRadius: 10, padding: "10px 18px", cursor: "pointer",
                          fontFamily: "inherit", fontSize: 13.5, fontWeight: 700,
                        }}
                      >
                        {waveEnCours === c.id ? "Redirection…" : "Payer avec Wave"}
                      </button>
                    )}

                    {enAttente ? (
                      <span style={{ fontSize: 12.5, color: C.textSubtle, alignSelf: "center" }}>
                        Déclaration envoyée, en attente de confirmation.
                      </span>
                    ) : moyens.length > 0 ? (
                      <button
                        onClick={() => setDeclarationOuverte(c)}
                        style={{
                          background: waveActif ? "transparent" : C.primary,
                          border: waveActif ? `1.5px solid ${C.border}` : "none",
                          color: waveActif ? C.text : "#fff",
                          borderRadius: 10, padding: "10px 18px", cursor: "pointer",
                          fontFamily: "inherit", fontSize: 13.5, fontWeight: 700,
                        }}
                      >
                        J'ai payé
                      </button>
                    ) : !waveActif ? (
                      <span style={{ fontSize: 12.5, color: C.textSubtle }}>
                        Aucun moyen de paiement configuré pour le moment — contactez le Bureau.
                      </span>
                    ) : null}
                  </div>
                )}

                <div style={{ fontSize: 11.5, color: C.textSubtle, marginTop: 10 }}>
                  Facultative : elle n'affecte pas votre statut de cotisation.
                </div>
              </div>
            );
          })}
        </div>
      )}

      {depuisCache && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8, background: "#FEF3C7",
          color: "#92400E", borderRadius: 10, padding: "10px 14px", fontSize: 12.5,
          marginBottom: 14, lineHeight: 1.4,
        }}>
          <WifiOff size={14} style={{ flexShrink: 0 }} />
          Dernières données connues du{" "}
          {new Date(horodatageCache).toLocaleDateString("fr-FR")} à{" "}
          {new Date(horodatageCache).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      )}

      {moyens.length > 0 && (cotisationsImpayees.length > 0 || exceptionnellesImpayees.length > 0) && (
        <MoyensPaiementApercu moyens={moyens} />
      )}

      {waveErreur && (
        <div style={{ background: C.dangerSoft, color: C.danger, borderRadius: 10, padding: 12, fontSize: 13, marginBottom: 14 }}>
          {waveErreur}
        </div>
      )}

      {/* Barre de sélection groupée — visible dès qu'au moins deux
          échéances sont sélectionnables, pour ne pas alourdir l'écran
          quand il n'y a qu'un seul mois en retard. */}
      {cotisationsImpayees.length > 1 && (
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10,
          background: selection.length > 0 ? PALETTE.blue50 : C.bg,
          border: `1px solid ${selection.length > 0 ? PALETTE.blue100 : C.border}`,
          borderRadius: 12, padding: "12px 16px", marginBottom: 14,
        }}>
          <div style={{ fontSize: 13, color: C.textMuted }}>
            {selection.length === 0
              ? "Cochez plusieurs échéances pour les régler en une seule fois."
              : <>{selection.length} échéance{selection.length > 1 ? "s" : ""} sélectionnée{selection.length > 1 ? "s" : ""} — <strong style={{ color: C.text }}>{montant(totalSelection)} FCFA</strong></>}
          </div>
          {selection.length > 0 && (
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {waveActif && (
                <button
                  onClick={payerSelectionAvecWave}
                  disabled={waveEnCours === "groupe"}
                  style={{
                    background: C.primary, border: "none", color: "#fff",
                    borderRadius: 8, padding: "8px 14px", cursor: "pointer",
                    fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                  }}
                >
                  {waveEnCours === "groupe" ? "Redirection…" : "Payer avec Wave"}
                </button>
              )}
              {moyens.length > 0 && (
                <button
                  onClick={() => setDeclarationOuverte(cotisationsSelectionnees)}
                  style={{
                    background: "none", border: `1.5px solid ${C.primary}`,
                    color: C.primary, borderRadius: 8, padding: "8px 14px", cursor: "pointer",
                    fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                  }}
                >
                  J'ai payé
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {cotisations.length === 0 ? (
        <div style={carteVide}>Aucune cotisation pour le moment.</div>
      ) : periodiques.length > 0 && (
        <div style={carteListe}>
          {periodiques.map((c, i) => {
            const st = c.statut === "paye"
              ? { bg: C.successSoft, fg: C.success, label: "Payé" }
              : c.statut === "partiel"
                ? { bg: C.warningSoft, fg: C.warning, label: "Partiel" }
                : { bg: C.dangerSoft, fg: C.danger, label: "En attente" };
            const enAttente = declarationEnAttentePour(c.id);
            const selectionnable = c.statut !== "paye" && !enAttente;

            return (
              <div
                key={c.id}
                style={{
                  display: "flex", gap: 12,
                  padding: "14px 18px",
                  borderBottom: i < periodiques.length - 1
                    ? `1px solid ${C.border}` : "none",
                }}
              >
                {/* Frise verticale — un repère par échéance, relié à la
                    suivante, pour lire l'historique comme une continuité
                    plutôt qu'une liste plate. */}
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 12, flexShrink: 0, paddingTop: 4 }}>
                  <div style={{ width: 10, height: 10, borderRadius: "50%", background: st.fg, flexShrink: 0 }} />
                  {i < periodiques.length - 1 && (
                    <div style={{ width: 2, flex: 1, minHeight: 18, background: C.border, marginTop: 4 }} />
                  )}
                </div>

                {cotisationsImpayees.length > 1 && (
                  <input
                    type="checkbox"
                    checked={selection.includes(c.id)}
                    onChange={() => basculerSelection(c.id)}
                    disabled={!selectionnable}
                    style={{ marginTop: 3, width: 16, height: 16, accentColor: C.primary, flexShrink: 0, visibility: selectionnable ? "visible" : "hidden" }}
                  />
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14.5 }}>
                        {formatPeriode(c.periode)}
                      </div>
                      <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 2 }}>
                        {montant(c.montant_paye)} / {montant(c.montant_du)} FCFA
                      </div>
                    </div>
                    <span style={{ ...badge, background: st.bg, color: st.fg }}>
                      {st.label}
                    </span>
                  </div>

                  {c.statut !== "paye" && (
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
                      {waveActif && (
                        <button
                          onClick={() => payerAvecWave(c)}
                          disabled={waveEnCours === c.id}
                          style={{
                            background: C.primary, border: "none", color: "#fff",
                            borderRadius: 8, padding: "7px 13px", cursor: "pointer",
                            fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                          }}
                        >
                          {waveEnCours === c.id ? "Redirection…" : "Payer avec Wave"}
                        </button>
                      )}

                      {moyens.length > 0 && (
                        enAttente ? (
                          <span style={{ fontSize: 12.5, color: C.textSubtle, alignSelf: "center" }}>
                            Déclaration envoyée, en attente de confirmation.
                          </span>
                        ) : (
                          <button
                            onClick={() => setDeclarationOuverte(c)}
                            style={{
                              background: "none", border: `1.5px solid ${C.primary}`,
                              color: C.primary, borderRadius: 8, padding: "7px 13px", cursor: "pointer",
                              fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                            }}
                          >
                            J'ai payé
                          </button>
                        )
                      )}

                      {!waveActif && moyens.length === 0 && (
                        <span style={{ fontSize: 12.5, color: C.textSubtle }}>
                          Aucun moyen de paiement configuré pour le moment — contactez le Bureau.
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {declarationOuverte && (
        <DeclarationPaiementModal
          cotisation={Array.isArray(declarationOuverte) ? null : declarationOuverte}
          cotisations={Array.isArray(declarationOuverte) ? declarationOuverte : null}
          membre={membre}
          moyens={moyens}
          onClose={() => setDeclarationOuverte(null)}
          onDone={() => { setDeclarationOuverte(null); charger(); }}
        />
      )}
    </div>
  );
}

// Récapitulatif compact des moyens de paiement de l'organisation, affiché
// en haut de l'écran — pour que le membre sache où envoyer l'argent avant
// même d'avoir besoin de déclarer un paiement.
const STATUTS_FORMATION = {
  planifiee: { label: "Planifiée", bg: PALETTE.blue100, fg: C.primary },
  terminee:  { label: "Terminée",  bg: C.successSoft,   fg: C.success },
  annulee:   { label: "Annulée",   bg: PALETTE.grey200, fg: C.textSubtle },
};

function MembreFormations({ membre }) {
  const [formations, setFormations] = useState([]);
  const [mesPresences, setMesPresences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [enCours, setEnCours] = useState(null);
  const [erreurAction, setErreurAction] = useState("");
  const [depuisCache, setDepuisCache] = useState(false);
  const [horodatageCache, setHorodatageCache] = useState(null);

  async function charger() {
    const idCache = `formations_${membre.id}`;

    const dejaEnCache = lireCache(idCache);
    if (dejaEnCache) {
      setFormations(dejaEnCache.donnees.formations);
      setMesPresences(dejaEnCache.donnees.mesPresences);
      setLoading(false);
    }

    try {
      const [fRes, pRes] = await Promise.all([
        supabase.from("formations").select("*").eq("organisation_id", membre.organisation_id).order("date_debut", { ascending: false }),
        supabase.from("formation_presences").select("*").eq("membre_id", membre.id),
      ]);

      for (const r of [fRes, pRes]) {
        if (r.error && ressembleAUneCoupureReseau(r.error)) throw r.error;
      }

      const resultat = { formations: fRes.data || [], mesPresences: pRes.data || [] };
      sauverCache(idCache, resultat);

      setFormations(resultat.formations);
      setMesPresences(resultat.mesPresences);
      setDepuisCache(false);
      setLoading(false);
    } catch (e) {
      const secours = lireCache(idCache);
      if (secours) {
        setFormations(secours.donnees.formations);
        setMesPresences(secours.donnees.mesPresences);
        setDepuisCache(true);
        setHorodatageCache(secours.horodatage);
      }
      setLoading(false);
    }
  }

  useEffect(() => { charger(); }, [membre.id]);

  const maPresence = (formationId) => mesPresences.find((p) => p.formation_id === formationId);

  async function inscrire(formation) {
    setEnCours(formation.id);
    setErreurAction("");
    const { error } = await supabase.from("formation_presences").insert({
      formation_id: formation.id,
      organisation_id: membre.organisation_id,
      membre_id: membre.id,
      statut: "inscrit",
    });
    setEnCours(null);
    if (error) {
      setErreurAction("L'inscription n'a pas abouti. Vérifiez votre connexion et réessayez.");
      return;
    }
    charger();
  }

  async function seDesinscrire(presence) {
    setEnCours(presence.formation_id);
    setErreurAction("");
    const { error } = await supabase.from("formation_presences").delete().eq("id", presence.id);
    setEnCours(null);
    if (error) {
      setErreurAction("La désinscription n'a pas abouti. Vérifiez votre connexion et réessayez.");
      return;
    }
    charger();
  }

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Formations</h2>

      {erreurAction && (
        <div style={{
          background: "#FEE2E2", color: C.danger, borderRadius: 10,
          padding: "11px 14px", fontSize: 13, marginBottom: 14, lineHeight: 1.4,
        }}>
          {erreurAction}
        </div>
      )}

      {depuisCache && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8, background: "#FEF3C7",
          color: "#92400E", borderRadius: 10, padding: "10px 14px", fontSize: 12.5,
          marginBottom: 14, lineHeight: 1.4,
        }}>
          <WifiOff size={14} style={{ flexShrink: 0 }} />
          Dernières données connues du{" "}
          {new Date(horodatageCache).toLocaleDateString("fr-FR")} à{" "}
          {new Date(horodatageCache).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      )}

      {formations.length === 0 ? (
        <div style={carteVide}>Aucune formation pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {formations.map((f, i) => {
            const st = STATUTS_FORMATION[f.statut] || STATUTS_FORMATION.planifiee;
            const presence = maPresence(f.id);

            return (
              <div
                key={f.id}
                style={{
                  padding: "14px 18px",
                  borderBottom: i < formations.length - 1 ? `1px solid ${C.border}` : "none",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14.5 }}>{f.titre}</div>
                    <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 2 }}>
                      {new Date(f.date_debut).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                      {f.lieu && ` · ${f.lieu}`}
                    </div>
                  </div>
                  <span style={{ ...badge, background: st.bg, color: st.fg }}>{st.label}</span>
                </div>

                {f.description && (
                  <div style={{ fontSize: 13, color: C.textMuted, marginTop: 6, lineHeight: 1.5 }}>
                    {f.description}
                  </div>
                )}

                <div style={{ marginTop: 10 }}>
                  {f.statut === "planifiee" ? (
                    presence ? (
                      <button
                        onClick={() => seDesinscrire(presence)}
                        disabled={enCours === f.id}
                        style={{
                          background: "none", border: `1.5px solid ${C.border}`, color: C.textMuted,
                          borderRadius: 8, padding: "7px 13px", cursor: "pointer",
                          fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                        }}
                      >
                        {enCours === f.id ? "…" : "Inscrit(e) · Se désinscrire"}
                      </button>
                    ) : (
                      <button
                        onClick={() => inscrire(f)}
                        disabled={enCours === f.id}
                        style={{
                          background: C.primary, border: "none", color: "#fff",
                          borderRadius: 8, padding: "7px 13px", cursor: "pointer",
                          fontFamily: "inherit", fontSize: 12.5, fontWeight: 600,
                        }}
                      >
                        {enCours === f.id ? "…" : "Je m'inscris"}
                      </button>
                    )
                  ) : presence && (
                    <span style={{ fontSize: 12.5, color: presence.statut === "present" ? C.success : C.textSubtle, fontWeight: 600 }}>
                      {presence.statut === "present" ? "Présent(e)" : presence.statut === "absent" ? "Absent(e)" : "Inscrit(e)"}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Deux catalogues, chacun en simple lecture — pas d'inscription ni de
// présence, contrairement aux formations. Le Bureau décide qui est
// visible via le bouton correspondant dans son propre écran.
function MembreServices({ membre }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("services_offerts")
      .select("*")
      .eq("organisation_id", membre.organisation_id)
      .eq("visible_membres", true)
      .eq("actif", true)
      .order("created_at", { ascending: false })
      .then(({ data }) => { setServices(data || []); setLoading(false); });
  }, [membre.organisation_id]);

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Services</h2>

      {services.length === 0 ? (
        <div style={carteVide}>Aucun service pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {services.map((s, i) => (
            <div
              key={s.id}
              style={{ padding: "14px 18px", borderBottom: i < services.length - 1 ? `1px solid ${C.border}` : "none" }}
            >
              <div style={{ fontWeight: 600, fontSize: 14.5 }}>{s.nom}</div>
              {s.description && (
                <div style={{ fontSize: 13, color: C.textMuted, marginTop: 4, lineHeight: 1.5 }}>
                  {s.description}
                </div>
              )}
              {s.tarif != null && (
                <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 6, fontWeight: 600 }}>
                  {montant(s.tarif)} FCFA
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MembrePartenaires({ membre }) {
  const [partenaires, setPartenaires] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("partenaires")
      .select("*")
      .eq("organisation_id", membre.organisation_id)
      .eq("visible_membres", true)
      .eq("actif", true)
      .order("created_at", { ascending: false })
      .then(({ data }) => { setPartenaires(data || []); setLoading(false); });
  }, [membre.organisation_id]);

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Partenaires</h2>

      {partenaires.length === 0 ? (
        <div style={carteVide}>Aucun partenaire pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {partenaires.map((p, i) => {
            const logoUrl = p.logo_chemin
              ? supabase.storage.from("logos-partenaires").getPublicUrl(p.logo_chemin).data.publicUrl
              : null;
            return (
              <div
                key={p.id}
                style={{
                  display: "flex", gap: 12, padding: "14px 18px",
                  borderBottom: i < partenaires.length - 1 ? `1px solid ${C.border}` : "none",
                }}
              >
                {logoUrl ? (
                  <img src={logoUrl} alt={p.nom} style={{ width: 40, height: 40, borderRadius: 8, objectFit: "cover", flexShrink: 0, border: `1px solid ${C.border}` }} />
                ) : (
                  <div style={{
                    width: 40, height: 40, borderRadius: 8, flexShrink: 0,
                    background: C.primaryLight + "22", color: C.primary,
                    display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700,
                  }}>
                    {p.nom.charAt(0).toUpperCase()}
                  </div>
                )}
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14.5 }}>{p.nom}</div>
                  {p.description && (
                    <div style={{ fontSize: 13, color: C.textMuted, marginTop: 3, lineHeight: 1.5 }}>
                      {p.description}
                    </div>
                  )}
                  <div style={{ display: "flex", gap: 10, marginTop: 6, fontSize: 12, color: C.textSubtle }}>
                    {p.site_web && (
                      <a href={p.site_web} target="_blank" rel="noreferrer" style={{ color: C.primary, fontWeight: 600, textDecoration: "none" }}>
                        Site web
                      </a>
                    )}
                    {p.contact && <span>{p.contact}</span>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

const PRODUITS_MEMBRE_LABELS = {
  attestation_adhesion: "Attestation d'adhésion",
  historique_cotisations: "Historique de cotisations",
};

// Un repère visuel distinct par document, plutôt qu'une simple ligne de
// texte — chacun a son icône et sa couleur propres, comme un vrai
// modèle de document plutôt qu'une liste indifférenciée.
const PRODUITS_MEMBRE_VISUELS = {
  attestation_adhesion: { Icon: Award, couleur: C.primary },
  historique_cotisations: { Icon: FileBarChart2, couleur: C.success },
};

// Le paiement va vers Babamoo lui-même, jamais vers l'organisation du
// membre — un circuit séparé de celui des cotisations, mais sur le même
// principe que DeclarationPaiementModal plus haut : pas de paiement en
// ligne automatisé, le membre déclare, l'exploitant confirme. Un achat
// déverrouille l'accès de façon permanente : pas de re-paiement pour
// régénérer le même document plus tard, il reflète toujours les
// données actuelles.
// Rassemble ce qui, jusqu'ici, était éparpillé module par module —
// assemblées et formations pour cette première version. Tontine et
// Prêts suivront une fois leurs échéances vérifiées : les prêts n'ont
// pas de colonne d'échéance simple (probablement plusieurs par prêt),
// pas question de deviner leur structure ici.
function MembreCalendrier({ membre }) {
  const [evenements, setEvenements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [depuisCache, setDepuisCache] = useState(false);
  const [horodatageCache, setHorodatageCache] = useState(null);

  async function charger() {
    const idCache = `calendrier_${membre.id}`;
    const maintenant = new Date().toISOString();

    const dejaEnCache = lireCache(idCache);
    if (dejaEnCache) {
      setEvenements(dejaEnCache.donnees);
      setLoading(false);
    }

    try {
      const [assRes, formRes] = await Promise.all([
        supabase.from("assemblees")
          .select("id, titre, date_prevue, lieu")
          .eq("organisation_id", membre.organisation_id)
          .gte("date_prevue", maintenant)
          .order("date_prevue"),
        supabase.from("formations")
          .select("id, titre, date_debut, lieu")
          .eq("organisation_id", membre.organisation_id)
          .gte("date_debut", maintenant)
          .order("date_debut"),
      ]);

      for (const r of [assRes, formRes]) {
        if (r.error && ressembleAUneCoupureReseau(r.error)) throw r.error;
      }

      const liste = [
        ...(assRes.data || []).map((a) => ({
          id: `assemblee-${a.id}`, type: "assemblee", titre: a.titre,
          date: a.date_prevue, lieu: a.lieu,
        })),
        ...(formRes.data || []).map((f) => ({
          id: `formation-${f.id}`, type: "formation", titre: f.titre,
          date: f.date_debut, lieu: f.lieu,
        })),
      ].sort((a, b) => new Date(a.date) - new Date(b.date));

      sauverCache(idCache, liste);
      setEvenements(liste);
      setDepuisCache(false);
      setLoading(false);
    } catch (e) {
      const secours = lireCache(idCache);
      if (secours) {
        setEvenements(secours.donnees);
        setDepuisCache(true);
        setHorodatageCache(secours.horodatage);
      }
      setLoading(false);
    }
  }

  useEffect(() => { charger(); }, [membre.organisation_id]);

  const ICONES_TYPE = { assemblee: Users2, formation: GraduationCap };
  const LABELS_TYPE = { assemblee: "Assemblée générale", formation: "Formation" };
  const COULEURS_TYPE = { assemblee: C.primary, formation: C.success };

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Mon calendrier</h2>

      {depuisCache && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8, background: "#FEF3C7",
          color: "#92400E", borderRadius: 10, padding: "10px 14px", fontSize: 12.5,
          marginBottom: 14, lineHeight: 1.4,
        }}>
          <WifiOff size={14} style={{ flexShrink: 0 }} />
          Dernières données connues du{" "}
          {new Date(horodatageCache).toLocaleDateString("fr-FR")} à{" "}
          {new Date(horodatageCache).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      )}

      {evenements.length === 0 ? (
        <div style={carteVide}>Rien de prévu pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {evenements.map((e, i) => {
            const Icone = ICONES_TYPE[e.type];
            const d = new Date(e.date);
            return (
              <div
                key={e.id}
                style={{
                  display: "flex", alignItems: "flex-start", gap: 14,
                  padding: "16px 18px",
                  borderBottom: i < evenements.length - 1 ? `1px solid ${C.border}` : "none",
                }}
              >
                <div style={{
                  width: 40, height: 40, borderRadius: 10, flexShrink: 0,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  background: `${COULEURS_TYPE[e.type]}18`, color: COULEURS_TYPE[e.type],
                }}>
                  <Icone size={19} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: COULEURS_TYPE[e.type] }}>
                    {LABELS_TYPE[e.type]}
                  </div>
                  <div style={{ fontWeight: 600, fontSize: 14.5, marginTop: 2 }}>{e.titre}</div>
                  <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 3 }}>
                    {d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                    {" à "}
                    {d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                    {e.lieu && ` · ${e.lieu}`}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Son propre historique de participation — assemblées où sa présence a
// été confirmée, formations suivies jusqu'au bout. Utile pour lui-même,
// et recoupe ce qui existe déjà : une attestation ou un futur CV
// associatif pourrait un jour s'appuyer sur les mêmes données.
function MembreHistorique({ membre }) {
  const [evenements, setEvenements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [depuisCache, setDepuisCache] = useState(false);
  const [horodatageCache, setHorodatageCache] = useState(null);

  async function charger() {
    const idCache = `historique_${membre.id}`;

    const dejaEnCache = lireCache(idCache);
    if (dejaEnCache) {
      setEvenements(dejaEnCache.donnees);
      setLoading(false);
    }

    try {
      const [assRes, formRes] = await Promise.all([
        supabase.from("assemblee_presences")
          .select("present, emarge_le, assemblees(titre, date_prevue, lieu)")
          .eq("membre_id", membre.id)
          .eq("present", true),
        supabase.from("formation_presences")
          .select("statut, formations(titre, date_debut, lieu)")
          .eq("membre_id", membre.id)
          .eq("statut", "present"),
      ]);

      for (const r of [assRes, formRes]) {
        if (r.error && ressembleAUneCoupureReseau(r.error)) throw r.error;
      }

      const liste = [
        ...(assRes.data || [])
          .filter((p) => p.assemblees)
          .map((p, i) => ({
            id: `assemblee-${i}`, type: "assemblee", titre: p.assemblees.titre,
            date: p.assemblees.date_prevue, lieu: p.assemblees.lieu,
          })),
        ...(formRes.data || [])
          .filter((p) => p.formations)
          .map((p, i) => ({
            id: `formation-${i}`, type: "formation", titre: p.formations.titre,
            date: p.formations.date_debut, lieu: p.formations.lieu,
          })),
      ].sort((a, b) => new Date(b.date) - new Date(a.date));

      sauverCache(idCache, liste);
      setEvenements(liste);
      setDepuisCache(false);
      setLoading(false);
    } catch (e) {
      const secours = lireCache(idCache);
      if (secours) {
        setEvenements(secours.donnees);
        setDepuisCache(true);
        setHorodatageCache(secours.horodatage);
      }
      setLoading(false);
    }
  }

  useEffect(() => { charger(); }, [membre.id]);

  const ICONES_TYPE = { assemblee: Users2, formation: GraduationCap };
  const LABELS_TYPE = { assemblee: "Assemblée générale", formation: "Formation" };
  const COULEURS_TYPE = { assemblee: C.primary, formation: C.success };

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Mon historique</h2>

      {depuisCache && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8, background: "#FEF3C7",
          color: "#92400E", borderRadius: 10, padding: "10px 14px", fontSize: 12.5,
          marginBottom: 14, lineHeight: 1.4,
        }}>
          <WifiOff size={14} style={{ flexShrink: 0 }} />
          Dernières données connues du{" "}
          {new Date(horodatageCache).toLocaleDateString("fr-FR")} à{" "}
          {new Date(horodatageCache).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      )}

      {evenements.length === 0 ? (
        <div style={carteVide}>Aucune participation enregistrée pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {evenements.map((e, i) => {
            const Icone = ICONES_TYPE[e.type];
            const d = new Date(e.date);
            return (
              <div
                key={e.id}
                style={{
                  display: "flex", alignItems: "flex-start", gap: 14,
                  padding: "16px 18px",
                  borderBottom: i < evenements.length - 1 ? `1px solid ${C.border}` : "none",
                }}
              >
                <div style={{
                  width: 40, height: 40, borderRadius: 10, flexShrink: 0,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  background: `${COULEURS_TYPE[e.type]}18`, color: COULEURS_TYPE[e.type],
                }}>
                  <Icone size={19} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: COULEURS_TYPE[e.type] }}>
                    {LABELS_TYPE[e.type]}
                  </div>
                  <div style={{ fontWeight: 600, fontSize: 14.5, marginTop: 2 }}>{e.titre}</div>
                  <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 3 }}>
                    {d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                    {e.lieu && ` · ${e.lieu}`}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function MembreDocuments({ membre }) {
  const { params } = useParametrage();
  const [produits, setProduits] = useState([]);
  const [achats, setAchats] = useState([]);
  const [declarationsEnAttente, setDeclarationsEnAttente] = useState([]);
  const [moyens, setMoyens] = useState([]);
  const [loading, setLoading] = useState(true);
  const [enCours, setEnCours] = useState(null);
  const [erreur, setErreur] = useState("");
  const [message, setMessage] = useState("");
  const [produitADeclarer, setProduitADeclarer] = useState(null);
  const [depuisCache, setDepuisCache] = useState(false);
  const [horodatageCache, setHorodatageCache] = useState(null);

  async function charger() {
    const idCache = `documents_${membre.id}`;

    const dejaEnCache = lireCache(idCache);
    if (dejaEnCache) {
      setProduits(dejaEnCache.donnees.produits);
      setAchats(dejaEnCache.donnees.achats);
      setDeclarationsEnAttente(dejaEnCache.donnees.declarationsEnAttente);
      setMoyens(dejaEnCache.donnees.moyens);
      setLoading(false);
    }

    try {
      const [pRes, aRes, dRes, mRes] = await Promise.all([
        supabase.from("produits_membre").select("*").eq("actif", true),
        supabase.from("achats_membre").select("produit_code").eq("membre_id", membre.id),
        supabase.from("declarations_paiement_membre").select("produit_code").eq("membre_id", membre.id).eq("statut", "en_attente"),
        supabase.from("moyens_paiement_plateforme").select("*").eq("actif", true),
      ]);

      for (const r of [pRes, aRes, dRes, mRes]) {
        if (r.error && ressembleAUneCoupureReseau(r.error)) throw r.error;
      }

      const resultat = {
        produits: pRes.data || [],
        achats: (aRes.data || []).map((x) => x.produit_code),
        declarationsEnAttente: (dRes.data || []).map((x) => x.produit_code),
        moyens: mRes.data || [],
      };
      sauverCache(idCache, resultat);

      setProduits(resultat.produits);
      setAchats(resultat.achats);
      setDeclarationsEnAttente(resultat.declarationsEnAttente);
      setMoyens(resultat.moyens);
      setDepuisCache(false);
      setLoading(false);
    } catch (e) {
      const secours = lireCache(idCache);
      if (secours) {
        setProduits(secours.donnees.produits);
        setAchats(secours.donnees.achats);
        setDeclarationsEnAttente(secours.donnees.declarationsEnAttente);
        setMoyens(secours.donnees.moyens);
        setDepuisCache(true);
        setHorodatageCache(secours.horodatage);
      }
      setLoading(false);
    }
  }

  useEffect(() => { charger(); }, [membre.id]);

  async function telecharger(produitCode) {
    setEnCours(produitCode);
    setErreur("");

    try {
      if (produitCode === "attestation_adhesion") {
        await genererAttestation({ membre, params });
      } else if (produitCode === "historique_cotisations") {
        const { data: cotisations } = await supabase
          .from("cotisations")
          .select("*")
          .eq("membre_id", membre.id);
        await genererHistorique({ membre, cotisations: cotisations || [], params });
      }
    } catch (e) {
      setErreur("Impossible de générer le document pour le moment.");
    }

    setEnCours(null);
  }

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Mes documents</h2>

      {depuisCache && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8, background: "#FEF3C7",
          color: "#92400E", borderRadius: 10, padding: "10px 14px", fontSize: 12.5,
          marginBottom: 14, lineHeight: 1.4,
        }}>
          <WifiOff size={14} style={{ flexShrink: 0 }} />
          Dernières données connues du{" "}
          {new Date(horodatageCache).toLocaleDateString("fr-FR")} à{" "}
          {new Date(horodatageCache).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
        </div>
      )}

      {message && (
        <div style={{ background: "#DCFCE7", color: C.success, borderRadius: 10, padding: 12, fontSize: 13, marginBottom: 14 }}>
          {message}
        </div>
      )}
      {erreur && (
        <div style={{ background: C.dangerSoft, color: C.danger, borderRadius: 10, padding: 12, fontSize: 13, marginBottom: 14 }}>
          {erreur}
        </div>
      )}

      {produits.length === 0 ? (
        <div style={carteVide}>Aucun document disponible pour le moment.</div>
      ) : (
        <div style={{
          display: "grid", gap: 14,
          gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
        }}>
          {produits.map((p) => {
            const achete = achats.includes(p.code);
            const enAttente = declarationsEnAttente.includes(p.code);
            const visuel = PRODUITS_MEMBRE_VISUELS[p.code] || { Icon: Award, couleur: C.primary };
            const VIcon = visuel.Icon;

            return (
              <div
                key={p.code}
                style={{
                  background: C.surface, border: `1px solid ${C.border}`,
                  borderRadius: R.xl, overflow: "hidden", boxShadow: SHADOW.xs,
                  display: "flex", flexDirection: "column",
                }}
              >
                {/* En-tête visuelle — sert de repère au document, comme un
                    modèle plutôt qu'une simple ligne de texte */}
                <div style={{
                  background: `linear-gradient(135deg, ${visuel.couleur}22, ${visuel.couleur}08)`,
                  padding: "22px 18px 18px",
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
                }}>
                  <div style={{
                    width: 46, height: 46, borderRadius: 12,
                    background: visuel.couleur, color: "#fff",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    boxShadow: `0 6px 16px -6px ${visuel.couleur}88`,
                  }}>
                    <VIcon size={22} />
                  </div>
                  <div style={{ fontWeight: 700, fontSize: 14.5, textAlign: "center" }}>
                    {PRODUITS_MEMBRE_LABELS[p.code] || p.libelle}
                  </div>
                </div>

                <div style={{ padding: "14px 16px", display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                  <div style={{ fontSize: 12.5, color: C.textSubtle, textAlign: "center" }}>
                    {achete
                      ? "Déjà acheté — téléchargeable à tout moment"
                      : enAttente
                        ? "Paiement déclaré — en attente de confirmation"
                        : `${montant(p.prix)} FCFA`}
                  </div>
                  <button
                    onClick={() => achete ? telecharger(p.code) : setProduitADeclarer(p)}
                    disabled={enCours === p.code || enAttente}
                    style={{
                      background: achete ? C.success : enAttente ? C.border : C.primary,
                      border: "none", color: enAttente ? C.textSubtle : "#fff",
                      borderRadius: 8, padding: "9px 16px", cursor: enAttente ? "default" : "pointer",
                      fontFamily: "inherit", fontSize: 13, fontWeight: 600, width: "100%",
                    }}
                  >
                    {enCours === p.code ? "…" : achete ? "Télécharger" : enAttente ? "En attente" : "J'ai payé"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {produitADeclarer && (
        <ModalDeclarerPaiementMembre
          membre={membre}
          produit={produitADeclarer}
          moyens={moyens}
          onClose={() => setProduitADeclarer(null)}
          onDone={() => {
            setProduitADeclarer(null);
            setMessage("Déclaration envoyée — en attente de confirmation.");
            setTimeout(() => setMessage(""), 4000);
            charger();
          }}
        />
      )}
    </div>
  );
}

// Même déclaration que DeclarationPaiementModal (cotisations), mais vers
// declarations_paiement_membre — le montant n'est jamais saisi par le
// membre : c'est le prix fixe du produit, pas un paiement partiel.
function ModalDeclarerPaiementMembre({ membre, produit, moyens, onClose, onDone }) {
  const [moyenId, setMoyenId] = useState(moyens[0]?.id || "");
  const [reference, setReference] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");

  const LABELS = { wave: "Wave", orange_money: "Orange Money", mtn_money: "MTN Money", moov_money: "Moov Money", autre: "Autre" };
  const moyenChoisi = moyens.find((m) => m.id === moyenId);
  const qrUrl = moyenChoisi?.qr_code_chemin
    ? supabase.storage.from("qr-plateforme").getPublicUrl(moyenChoisi.qr_code_chemin).data.publicUrl
    : null;

  async function envoyer() {
    if (!moyenId) { setErreur("Choisissez un moyen de paiement."); return; }

    setEnCours(true);
    setErreur("");

    const { error } = await supabase.from("declarations_paiement_membre").insert({
      membre_id: membre.id,
      produit_code: produit.code,
      moyen_paiement_id: moyenId,
      montant: produit.prix,
      reference: reference.trim() || null,
    });

    setEnCours(false);

    if (error) { setErreur(error.message); return; }
    onDone();
  }

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 200, background: "rgba(10,20,40,.5)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: "#fff", borderRadius: 20, padding: 24, width: "100%", maxWidth: 420 }}
      >
        <h3 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 4px" }}>J'ai payé</h3>
        <p style={{ fontSize: 13, color: C.textSubtle, margin: "0 0 16px" }}>
          {PRODUITS_MEMBRE_LABELS[produit.code] || produit.libelle} — {montant(produit.prix)} FCFA
        </p>

        {moyens.length === 0 ? (
          <div style={{ background: C.dangerSoft, color: C.danger, borderRadius: 8, padding: 10, fontSize: 13, marginBottom: 14 }}>
            Aucun moyen de paiement disponible pour le moment.
          </div>
        ) : (
          <>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Moyen utilisé</label>
              <select
                value={moyenId}
                onChange={(e) => setMoyenId(e.target.value)}
                style={{ width: "100%", marginTop: 6, padding: 10, borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: "inherit", fontSize: 14 }}
              >
                {moyens.map((m) => (
                  <option key={m.id} value={m.id}>{m.libelle || LABELS[m.type] || m.type}</option>
                ))}
              </select>
            </div>

            {moyenChoisi && (
              <div style={{ background: C.bg, borderRadius: 10, padding: 12, marginBottom: 14 }}>
                {moyenChoisi.lien && (
                  <div style={{ fontSize: 13 }}>
                    <a href={moyenChoisi.lien} target="_blank" rel="noreferrer" style={{ color: C.primary, fontWeight: 600 }}>
                      Ouvrir le lien de paiement
                    </a>
                  </div>
                )}
                {moyenChoisi.numero && (
                  <div style={{ fontSize: 13, marginTop: moyenChoisi.lien ? 6 : 0 }}>
                    Numéro : <strong>{moyenChoisi.numero}</strong>
                  </div>
                )}
                {qrUrl && (
                  <img src={qrUrl} alt="QR code" style={{ width: 120, height: 120, marginTop: 8, borderRadius: 8, border: `1px solid ${C.border}` }} />
                )}
                {moyenChoisi.instructions && (
                  <div style={{ fontSize: 12.5, color: C.textMuted, marginTop: 6 }}>{moyenChoisi.instructions}</div>
                )}
              </div>
            )}

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Référence — facultative</label>
              <input
                value={reference} onChange={(e) => setReference(e.target.value)}
                placeholder="Numéro de transaction, si vous l'avez"
                style={{ width: "100%", marginTop: 6, padding: 10, borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: "inherit", fontSize: 14, boxSizing: "border-box" }}
              />
            </div>
          </>
        )}

        {erreur && (
          <div style={{ background: C.dangerSoft, color: C.danger, borderRadius: 8, padding: 10, fontSize: 13, marginBottom: 14 }}>
            {erreur}
          </div>
        )}

        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={onClose} disabled={enCours}
            style={{ flex: 1, background: "#fff", border: `1.5px solid ${C.border}`, color: C.textMuted, borderRadius: 10, padding: "12px 0", cursor: "pointer", fontFamily: "inherit", fontSize: 14, fontWeight: 600 }}
          >
            Annuler
          </button>
          <button
            onClick={envoyer} disabled={enCours || moyens.length === 0}
            style={{ flex: 2, background: C.primary, border: "none", color: "#fff", borderRadius: 10, padding: "12px 0", cursor: "pointer", fontFamily: "inherit", fontSize: 14, fontWeight: 600 }}
          >
            {enCours ? "Envoi…" : "Envoyer"}
          </button>
        </div>
      </div>
    </div>
  );
}

function MoyensPaiementApercu({ moyens }) {
  const LABELS = { wave: "Wave", orange_money: "Orange Money", mtn_money: "MTN Money", moov_money: "Moov Money", autre: "Autre" };
  return (
    <div style={{ ...carteVide, textAlign: "left", padding: "14px 18px", marginBottom: 14 }}>
      <div style={{ fontWeight: 600, fontSize: 13.5, marginBottom: 10 }}>Comment payer</div>
      {moyens.map((m) => {
        const logoUrl = m.logo_chemin
          ? supabase.storage.from("qr-paiement").getPublicUrl(m.logo_chemin).data.publicUrl
          : null;
        const nom = m.libelle || LABELS[m.type] || m.type;

        return (
          <div key={m.id} style={{ display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 12 }}>
            {m.lien ? (
              <a href={m.lien} target="_blank" rel="noreferrer" style={{ flexShrink: 0 }}>
                {logoUrl ? (
                  <img
                    src={logoUrl} alt={nom}
                    style={{ width: 34, height: 34, borderRadius: 8, objectFit: "cover", cursor: "pointer", border: `1px solid ${C.border}` }}
                  />
                ) : (
                  <div style={{
                    width: 34, height: 34, borderRadius: 8, cursor: "pointer",
                    background: C.primaryLight + "22", color: C.primary,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontWeight: 700, fontSize: 13,
                  }}>
                    {(nom || "?").charAt(0).toUpperCase()}
                  </div>
                )}
              </a>
            ) : logoUrl ? (
              <img
                src={logoUrl} alt={nom}
                style={{ width: 34, height: 34, borderRadius: 8, objectFit: "cover", flexShrink: 0, border: `1px solid ${C.border}` }}
              />
            ) : (
              <div style={{
                width: 34, height: 34, borderRadius: 8, flexShrink: 0,
                background: C.primaryLight + "22", color: C.primary,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontWeight: 700, fontSize: 13,
              }}>
                {(nom || "?").charAt(0).toUpperCase()}
              </div>
            )}

            <div style={{ flex: 1, fontSize: 13, color: C.textMuted }}>
              <strong style={{ color: C.text }}>{nom}</strong>
              {m.numero && <div style={{ marginTop: 2 }}>{m.numero}</div>}
              {m.instructions && <div style={{ fontSize: 12.5, marginTop: 2 }}>{m.instructions}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Déclaration d'un paiement par le membre — ne crée jamais de paiement
// réel : seulement une demande que le Bureau confirme ou rejette dans
// "Paiements déclarés", exactement comme aujourd'hui pour un règlement
// signalé par un autre canal, sans la ressaisie manuelle.
// Accepte soit une cotisation unique (cotisation), soit un tableau
// (cotisations) — jamais les deux à la fois. Le second cas insère une
// seule déclaration avec cotisation_ids renseigné et cotisation_id
// laissé vide, plutôt que plusieurs déclarations distinctes à
// confirmer une par une côté Bureau.
function DeclarationPaiementModal({ cotisation, cotisations, membre, moyens, onClose, onDone }) {
  const liste = cotisations || (cotisation ? [cotisation] : []);
  const groupe = liste.length > 1;
  const restant = liste.reduce((s, c) => s + ((c.montant_du || 0) - (c.montant_paye || 0)), 0);
  const [moyenId, setMoyenId] = useState(moyens[0]?.id || "");
  const [montantSaisi, setMontantSaisi] = useState(String(restant));
  const [reference, setReference] = useState("");
  const [note, setNote] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");

  // Même libellés que MoyensPaiementApercu — cohérence d'affichage entre
  // le récapitulatif "Comment payer" et cet écran de déclaration.
  const LABELS_MOYEN = { wave: "Wave", orange_money: "Orange Money", mtn_money: "MTN Money", moov_money: "Moov Money", autre: "Autre" };

  async function envoyer() {
    const m = parseInt(montantSaisi, 10);
    if (!m || m <= 0) { setErreur("Indiquez le montant payé."); return; }

    setEnCours(true);
    setErreur("");

    const { error } = await supabase.from("declarations_paiement").insert({
      organisation_id: membre.organisation_id,
      membre_id: membre.id,
      cotisation_id: groupe ? null : liste[0].id,
      cotisation_ids: groupe ? liste.map((c) => c.id) : null,
      moyen_paiement_id: moyenId || null,
      montant: m,
      reference: reference.trim() || null,
      note: note.trim() || null,
    });

    setEnCours(false);

    if (error) { setErreur(error.message); return; }
    onDone();
  }

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 200, background: "rgba(10,20,40,.5)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
        overflowY: "auto",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: "#fff", borderRadius: 20, width: "100%", maxWidth: 420, overflow: "hidden", margin: "auto" }}
      >
        {/* ---- Bandeau ---- */}
        <div style={{
          position: "relative", overflow: "hidden",
          background: `linear-gradient(135deg, ${PALETTE.blue800}, ${PALETTE.blue600})`,
          color: "#fff", padding: "20px 22px",
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14,
        }}>
          <div style={{
            position: "absolute", width: 160, height: 160, borderRadius: "50%",
            background: "rgba(255,255,255,.08)", right: -50, top: -60,
          }} />
          <div style={{ position: "relative" }}>
            <div style={{ fontSize: 16, fontWeight: 700, lineHeight: 1.35 }}>
              Finaliser votre paiement{" "}
              {groupe ? `de ${liste.length} échéances` : `pour ${libelleCotisation(liste[0])}`}
            </div>
            <span style={{
              display: "inline-flex", marginTop: 8,
              background: "rgba(255,255,255,.18)", borderRadius: 999,
              padding: "4px 11px", fontSize: 11.5, fontWeight: 700, letterSpacing: ".02em",
            }}>
              À PAYER
            </span>
          </div>
          <AvatarStatutMembre sexe={membre.sexe} aJour hauteur={76} />
        </div>

        <div style={{ padding: "20px 22px 22px" }}>
          {/* ---- Récapitulatif ---- */}
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            background: C.bg, border: `1px solid ${C.border}`, borderRadius: 12,
            padding: "13px 15px", marginBottom: 16,
          }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 700 }}>
                {groupe
                  ? `${liste.length} échéances (${liste.map((c) => libelleCotisation(c)).join(", ")})`
                  : libelleCotisation(liste[0])}
              </div>
              <div style={{ fontSize: 12, color: C.textSubtle, marginTop: 2 }}>
                {liste[0]?.type === "exceptionnelle" ? "Cotisation exceptionnelle" : "Cotisation"}
              </div>
            </div>
            <div style={{ fontSize: 17, fontWeight: 700 }}>{montant(restant)} FCFA</div>
          </div>

          {/* ---- Mode de paiement ---- */}
          {moyens.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Mode de paiement</label>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 8 }}>
                {moyens.map((m) => {
                  const actif = moyenId === m.id;
                  const nom = m.libelle || LABELS_MOYEN[m.type] || m.type;
                  const logoUrl = m.logo_chemin
                    ? supabase.storage.from("qr-paiement").getPublicUrl(m.logo_chemin).data.publicUrl
                    : null;

                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setMoyenId(m.id)}
                      style={{
                        display: "flex", alignItems: "center", gap: 8,
                        border: `1.5px solid ${actif ? C.primary : C.border}`,
                        background: actif ? PALETTE.blue50 : "#fff",
                        borderRadius: 10, padding: "9px 11px", cursor: "pointer",
                        fontFamily: "inherit", textAlign: "left",
                      }}
                    >
                      {logoUrl ? (
                        <img src={logoUrl} alt="" style={{ width: 26, height: 26, borderRadius: 7, objectFit: "cover", flexShrink: 0 }} />
                      ) : (
                        <span style={{
                          width: 26, height: 26, borderRadius: 7, flexShrink: 0,
                          background: actif ? C.primary : PALETTE.grey200,
                          color: actif ? "#fff" : C.textSubtle,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 12, fontWeight: 700,
                        }}>
                          {(nom || "?").charAt(0).toUpperCase()}
                        </span>
                      )}
                      <span style={{ fontSize: 12.5, fontWeight: 600, color: actif ? C.primary : C.text, lineHeight: 1.25 }}>
                        {nom}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Montant payé</label>
            <input
              type="number" value={montantSaisi} onChange={(e) => setMontantSaisi(e.target.value)}
              style={{ width: "100%", marginTop: 6, padding: 10, borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: "inherit", fontSize: 14, boxSizing: "border-box" }}
            />
          </div>

          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Référence — facultative</label>
            <input
              value={reference} onChange={(e) => setReference(e.target.value)}
              placeholder="Numéro de transaction, si vous l'avez"
              style={{ width: "100%", marginTop: 6, padding: 10, borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: "inherit", fontSize: 14, boxSizing: "border-box" }}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Note — facultative</label>
            <input
              value={note} onChange={(e) => setNote(e.target.value)}
              style={{ width: "100%", marginTop: 6, padding: 10, borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: "inherit", fontSize: 14, boxSizing: "border-box" }}
            />
          </div>

          {erreur && (
            <div style={{ background: C.dangerSoft, color: C.danger, borderRadius: 8, padding: 10, fontSize: 13, marginBottom: 14 }}>
              {erreur}
            </div>
          )}

          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={onClose} disabled={enCours}
              style={{ flex: 1, background: "#fff", border: `1.5px solid ${C.border}`, color: C.textMuted, borderRadius: 10, padding: "12px 0", cursor: "pointer", fontFamily: "inherit", fontSize: 14, fontWeight: 600 }}
            >
              Annuler
            </button>
            <button
              onClick={envoyer} disabled={enCours}
              style={{ flex: 2, background: C.primary, border: "none", color: "#fff", borderRadius: 10, padding: "12px 0", cursor: "pointer", fontFamily: "inherit", fontSize: 14, fontWeight: 600 }}
            >
              {enCours ? "Envoi…" : "Payer maintenant"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Tombola du membre ---------------- */

function MembreTombola({ membre }) {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("tombola_tickets")
      .select("*")
      .eq("membre_id", membre.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setTickets(data || []);
        setLoading(false);
      });
  }, [membre.id]);

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Mes tickets tombola</h2>

      {tickets.length === 0 ? (
        <div style={carteVide}>
          Aucun ticket pour le moment. Un ticket bonus vous est attribué
          automatiquement dès qu'une cotisation est réglée.
        </div>
      ) : (
        <div style={carteListe}>
          {tickets.map((t, i) => (
            <div
              key={t.id}
              style={{
                display: "flex", justifyContent: "space-between",
                alignItems: "center", padding: "14px 18px",
                borderBottom: i < tickets.length - 1
                  ? `1px solid ${C.border}` : "none",
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>
                  {t.type_ticket === "bonus" ? "Ticket bonus" : "Ticket acheté"}
                </div>
                <div style={{ fontSize: 12.5, color: C.textSubtle, marginTop: 2 }}>
                  Trimestre {t.trimestre}
                </div>
              </div>
              <span
                style={{
                  ...badge,
                  background: t.eligible_gain ? C.successSoft : C.dangerSoft,
                  color: t.eligible_gain ? C.success : C.danger,
                }}
              >
                {t.eligible_gain ? "Éligible" : "Non éligible"}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Assemblées générales — vue membre ---------------- */

function MembreAssemblees({ membre }) {
  const { params } = useParametrage();
  const [assemblees, setAssemblees] = useState([]);
  const [presences, setPresences] = useState({});
  const [loading, setLoading] = useState(true);
  const [codeSaisi, setCodeSaisi] = useState({});
  const [enCours, setEnCours] = useState(null);
  const [messages, setMessages] = useState({});

  async function charger() {
    const [aRes, pRes] = await Promise.all([
      supabase.from("assemblees")
        .select("*")
        .eq("organisation_id", params.organisation_id)
        .order("date_prevue", { ascending: false }),
      supabase.from("assemblee_presences")
        .select("*")
        .eq("membre_id", membre.id),
    ]);
    setAssemblees(aRes.data || []);
    const map = {};
    (pRes.data || []).forEach((p) => { map[p.assemblee_id] = p; });
    setPresences(map);
    setLoading(false);
  }

  useEffect(() => {
    if (!params.organisation_id) return;
    charger();
  }, [params.organisation_id, membre.id]);

  async function pointer(assembleeId) {
    const code = (codeSaisi[assembleeId] || "").trim();
    if (code.length !== 6) {
      setMessages((m) => ({ ...m, [assembleeId]: { type: "err", texte: "Le code comporte 6 chiffres." } }));
      return;
    }

    setEnCours(assembleeId);
    const { error } = await supabase.rpc("emarger_avec_code", {
      p_assemblee_id: assembleeId,
      p_code: code,
    });
    setEnCours(null);

    if (error) {
      setMessages((m) => ({ ...m, [assembleeId]: { type: "err", texte: error.message } }));
      return;
    }

    setMessages((m) => ({ ...m, [assembleeId]: { type: "ok", texte: "Présence enregistrée." } }));
    charger();
  }

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  return (
    <div>
      <h2 style={titrePage}>Assemblées générales</h2>

      {assemblees.length === 0 ? (
        <div style={carteVide}>Aucune assemblée générale annoncée pour le moment.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {assemblees.map((a) => {
            const presence = presences[a.id];
            const message = messages[a.id];
            const passee = new Date(a.date_prevue) < new Date();

            return (
              <div key={a.id} style={carteListe}>
                <div style={{ padding: "16px 18px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                    <div style={{ fontWeight: 700, fontSize: 15.5 }}>{a.titre}</div>
                    <span
                      style={{
                        ...badge,
                        background: presence?.present ? C.successSoft : C.warningSoft,
                        color: presence?.present ? C.success : C.warning,
                      }}
                    >
                      {presence?.present ? "Présence enregistrée" : "Non pointé"}
                    </span>
                  </div>

                  <div style={{ fontSize: 13, color: C.textSubtle, marginTop: 4 }}>
                    {new Date(a.date_prevue).toLocaleString("fr-FR", { dateStyle: "long", timeStyle: "short" })}
                    {a.lieu ? ` · ${a.lieu}` : ""}
                  </div>

                  {a.ordre_du_jour && (
                    <div style={{ fontSize: 13.5, color: C.textMuted, marginTop: 10, whiteSpace: "pre-line", lineHeight: 1.6 }}>
                      {a.ordre_du_jour}
                    </div>
                  )}

                  {!presence?.present && !passee && (
                    <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                      <input
                        value={codeSaisi[a.id] || ""}
                        onChange={(e) => setCodeSaisi((c) => ({ ...c, [a.id]: e.target.value.replace(/\D/g, "").slice(0, 6) }))}
                        placeholder="Code à 6 chiffres"
                        style={{
                          flex: 1, border: `1px solid ${C.border}`, borderRadius: R.md,
                          padding: "10px 12px", fontSize: 15, letterSpacing: "0.15em",
                          fontFamily: "'Inter', system-ui, sans-serif",
                        }}
                      />
                      <button
                        onClick={() => pointer(a.id)}
                        disabled={enCours === a.id}
                        style={{
                          background: C.primary, color: "#fff", border: "none",
                          borderRadius: R.md, padding: "10px 16px", fontWeight: 600,
                          fontSize: 13.5, cursor: "pointer", fontFamily: "'Inter', system-ui, sans-serif",
                          opacity: enCours === a.id ? 0.6 : 1,
                        }}
                      >
                        Pointer
                      </button>
                    </div>
                  )}

                  {message && (
                    <div
                      style={{
                        ...encart, marginTop: 10,
                        background: message.type === "ok" ? C.successSoft : C.dangerSoft,
                        color: message.type === "ok" ? C.success : C.danger,
                      }}
                    >
                      {message.texte}
                    </div>
                  )}

                  {a.statut === "cloturee" && (a.pv_texte || a.pv_url) && (
                    <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${C.border}` }}>
                      <div style={{ fontWeight: 600, fontSize: 13.5, marginBottom: 6 }}>Procès-verbal</div>
                      {a.pv_texte && (
                        <div style={{ fontSize: 13.5, color: C.textMuted, whiteSpace: "pre-line", lineHeight: 1.6 }}>
                          {a.pv_texte}
                        </div>
                      )}
                      {a.pv_url && (
                        <a href={a.pv_url} target="_blank" rel="noreferrer" style={{ color: C.primary, fontSize: 13.5, fontWeight: 600 }}>
                          Voir le document joint
                        </a>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Tontine — vue membre ---------------- */

function MembreTontine({ membre }) {
  const { params } = useParametrage();
  const [tontine, setTontine] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [tours, setTours] = useState([]);
  const [versements, setVersements] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!params.organisation_id) return;
    (async () => {
      const { data: tData } = await supabase
        .from("tontines")
        .select("*")
        .eq("organisation_id", params.organisation_id)
        .eq("statut", "en_cours")
        .maybeSingle();

      if (!tData) { setLoading(false); return; }
      setTontine(tData);

      const [pRes, tRes] = await Promise.all([
        supabase.from("tontine_participants").select("*, membres(nom)").eq("tontine_id", tData.id).order("rang"),
        supabase.from("tontine_tours").select("*, membres:beneficiaire_membre_id(nom)").eq("tontine_id", tData.id).order("numero_tour"),
      ]);
      setParticipants(pRes.data || []);
      setTours(tRes.data || []);

      const tourEnCours = (tRes.data || []).find((t) => t.statut === "en_cours");
      if (tourEnCours) {
        const { data: vData } = await supabase
          .from("tontine_versements")
          .select("*")
          .eq("tour_id", tourEnCours.id);
        const map = {};
        (vData || []).forEach((v) => { map[v.membre_id] = v; });
        setVersements(map);
      }

      setLoading(false);
    })();
  }, [params.organisation_id]);

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  if (!tontine) {
    return (
      <div>
        <h2 style={titrePage}>Tontine</h2>
        <div style={carteVide}>Aucune tontine en cours pour le moment.</div>
      </div>
    );
  }

  const monRang = participants.find((p) => p.membre_id === membre.id)?.rang;
  const tourActuel = tours.find((t) => t.statut === "en_cours");
  const jaiVerse = tourActuel && !!versements[membre.id];

  return (
    <div>
      <h2 style={titrePage}>{tontine.titre}</h2>

      <div style={carteVide}>
        <div style={{ fontSize: 14, color: C.text, marginBottom: 6 }}>
          {tontine.montant_part.toLocaleString("fr-FR")} FCFA par tour
          {monRang && <> · votre position : {monRang}ᵉ</>}
        </div>
      </div>

      {tourActuel && (
        <div style={{ ...carteListe, marginTop: 14, padding: "16px 18px" }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>Tour {tourActuel.numero_tour}</div>
          <div style={{ fontSize: 13.5, color: C.textMuted, marginTop: 4 }}>
            Bénéficiaire : {tourActuel.membres?.nom}
          </div>
          <span
            style={{
              ...badge, marginTop: 10, display: "inline-flex",
              background: jaiVerse ? C.successSoft : C.warningSoft,
              color: jaiVerse ? C.success : C.warning,
            }}
          >
            {jaiVerse ? "Votre part est versée" : "Votre part n'est pas encore enregistrée"}
          </span>
        </div>
      )}

      <div style={{ ...carteListe, marginTop: 14 }}>
        {tours.map((t, i) => (
          <div
            key={t.id}
            style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 18px",
              borderBottom: i < tours.length - 1 ? `1px solid ${C.border}` : "none",
            }}
          >
            <div style={{ fontSize: 13.5 }}>
              <strong>{t.numero_tour}.</strong> {t.membres?.nom}
            </div>
            <span style={{ fontSize: 12, color: t.statut === "cloture" ? C.success : t.statut === "en_cours" ? C.primary : C.textSubtle, fontWeight: 600 }}>
              {t.statut === "cloture" ? "Perçu" : t.statut === "en_cours" ? "En cours" : "À venir"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Prêts — vue membre ---------------- */

function MembrePrets({ membre }) {
  const { params } = useParametrage();
  const [prets, setPrets] = useState([]);
  const [types, setTypes] = useState([]);
  const [echeances, setEcheances] = useState({});
  const [loading, setLoading] = useState(true);
  const [demande, setDemande] = useState(false);
  const [typeChoisi, setTypeChoisi] = useState(null);
  const [montant, setMontant] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [erreur, setErreur] = useState("");

  async function charger() {
    setLoading(true);
    const [pRes, tRes] = await Promise.all([
      supabase.from("prets").select("*").eq("membre_id", membre.id).order("demande_le", { ascending: false }),
      supabase.from("types_pret").select("*").eq("organisation_id", params.organisation_id).eq("actif", true).order("ordre"),
    ]);
    setPrets(pRes.data || []);
    setTypes(tRes.data || []);

    const enCoursIds = (pRes.data || []).filter((p) => p.statut === "approuve").map((p) => p.id);
    if (enCoursIds.length > 0) {
      const { data: eData } = await supabase.from("pret_echeances").select("*").in("pret_id", enCoursIds).order("numero_echeance");
      const map = {};
      (eData || []).forEach((e) => { (map[e.pret_id] ||= []).push(e); });
      setEcheances(map);
    }

    setLoading(false);
  }

  useEffect(() => {
    if (!params.organisation_id) return;
    charger();
  }, [params.organisation_id, membre.id]);

  async function soumettre() {
    if (!typeChoisi) { setErreur("Choisissez un type de prêt."); return; }
    if (!montant || Number(montant) <= 0) { setErreur("Montant invalide."); return; }
    if (typeChoisi.plafond_montant && Number(montant) > typeChoisi.plafond_montant) {
      setErreur(`Ce type de prêt est plafonné à ${typeChoisi.plafond_montant.toLocaleString("fr-FR")} FCFA.`);
      return;
    }

    setEnvoi(true);
    setErreur("");

    const { error } = await supabase.from("prets").insert({
      organisation_id: params.organisation_id,
      membre_id: membre.id,
      type_pret_id: typeChoisi.id,
      libelle_type: typeChoisi.libelle,
      taux_interet_pct: typeChoisi.taux_interet_pct,
      mode_remboursement: typeChoisi.mode_remboursement,
      nombre_echeances: typeChoisi.mode_remboursement === "echelonne" ? typeChoisi.nombre_echeances : 1,
      montant_principal: Number(montant),
      statut: "en_attente",
      initiee_par: "membre",
    });

    setEnvoi(false);
    if (error) { setErreur(error.message); return; }
    setDemande(false);
    setTypeChoisi(null);
    setMontant("");
    charger();
  }

  if (loading) return <div style={{ color: C.textSubtle }}>Chargement…</div>;

  if (demande) {
    return (
      <div>
        <button style={lienRetour} onClick={() => setDemande(false)}>‹ Annuler</button>
        <h2 style={titrePage}>Demander un prêt</h2>

        {types.length === 0 ? (
          <div style={carteVide}>Aucun type de prêt n'est disponible pour le moment.</div>
        ) : (
          <>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
              {types.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTypeChoisi(t)}
                  style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    border: `1px solid ${typeChoisi?.id === t.id ? C.primary : C.border}`,
                    background: typeChoisi?.id === t.id ? PALETTE.blue100 : C.surface,
                    borderRadius: R.md, padding: "12px 14px", cursor: "pointer",
                    fontFamily: "'Inter', system-ui, sans-serif", textAlign: "left",
                  }}
                >
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{t.libelle}</span>
                  <span style={{ fontSize: 12, color: C.textSubtle }}>
                    {t.taux_interet_pct}% · {t.mode_remboursement === "unique" ? "en une fois" : `${t.nombre_echeances} échéances`}
                  </span>
                </button>
              ))}
            </div>

            <label style={{ fontSize: 12.5, fontWeight: 600, color: C.textMuted }}>Montant souhaité (FCFA)</label>
            <input
              type="number" min={1} value={montant} onChange={(e) => setMontant(e.target.value)}
              style={{
                width: "100%", border: `1px solid ${C.border}`, borderRadius: R.md, padding: "10px 12px",
                fontFamily: "'Inter', system-ui, sans-serif", fontSize: 14, boxSizing: "border-box", marginTop: 6, marginBottom: 14,
              }}
            />

            {erreur && (
              <div style={{ ...encart, background: C.dangerSoft, color: C.danger, marginBottom: 12 }}>{erreur}</div>
            )}

            <button
              onClick={soumettre} disabled={envoi}
              style={{
                width: "100%", background: C.primary, color: "#fff", border: "none",
                borderRadius: R.md, padding: "13px", fontWeight: 600, fontSize: 14.5,
                cursor: "pointer", fontFamily: "'Inter', system-ui, sans-serif", opacity: envoi ? 0.6 : 1,
              }}
            >
              {envoi ? "Envoi…" : "Soumettre la demande"}
            </button>
          </>
        )}
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ ...titrePage, margin: 0 }}>Mes prêts</h2>
        <button
          onClick={() => setDemande(true)}
          style={{
            background: C.primary, color: "#fff", border: "none", borderRadius: R.md,
            padding: "9px 15px", fontWeight: 600, fontSize: 13, cursor: "pointer",
            fontFamily: "'Inter', system-ui, sans-serif",
          }}
        >
          Demander
        </button>
      </div>

      {prets.length === 0 ? (
        <div style={carteVide}>Vous n'avez aucune demande de prêt pour le moment.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {prets.map((p) => {
            const couleurs = {
              en_attente: { bg: C.warningSoft, fg: C.warning, label: "En attente" },
              approuve:   { bg: PALETTE.blue100, fg: C.primary, label: "En cours" },
              solde:      { bg: C.successSoft, fg: C.success, label: "Soldé" },
              rejete:     { bg: C.dangerSoft, fg: C.danger, label: "Rejeté" },
            }[p.statut];

            return (
              <div key={p.id} style={carteListe}>
                <div style={{ padding: "14px 18px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>{p.libelle_type}</div>
                    <span style={{ ...badge, background: couleurs.bg, color: couleurs.fg }}>{couleurs.label}</span>
                  </div>
                  <div style={{ fontSize: 13, color: C.textSubtle, marginTop: 4 }}>
                    {p.montant_principal.toLocaleString("fr-FR")} FCFA
                    {p.taux_interet_pct > 0 && ` + ${p.taux_interet_pct}% d'intérêt`}
                    {" · total "}{p.montant_total_a_rembourser.toLocaleString("fr-FR")} FCFA
                  </div>

                  {p.statut === "rejete" && p.motif_rejet && (
                    <div style={{ ...encart, marginTop: 10, background: C.dangerSoft, color: C.danger }}>
                      {p.motif_rejet}
                    </div>
                  )}

                  {p.statut === "approuve" && echeances[p.id] && (
                    <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${C.border}` }}>
                      {echeances[p.id].map((e) => (
                        <div key={e.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "4px 0" }}>
                          <span>Échéance {e.numero_echeance} — {new Date(e.date_prevue).toLocaleDateString("fr-FR")}</span>
                          <span style={{ color: e.montant_paye ? C.success : C.textSubtle, fontWeight: 600 }}>
                            {e.montant_paye ? "Réglée" : "En attente"}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Aides — vue administrateur ---------------- */

const STATUTS_AIDE = ["en_attente", "en_examen", "validee", "payee", "rejetee"];

const LIBELLES_STATUT = {
  en_attente: "En attente",
  en_examen: "En examen",
  validee: "Validée",
  payee: "Payée",
  rejetee: "Rejetée",
};

const COULEURS_STATUT = {
  en_attente: C.textMuted,
  en_examen: C.warning,
  validee: C.success,
  payee: C.success,
  rejetee: C.danger,
};

// Le membre ne doit pas avoir à revenir vérifier lui-même si sa demande
// a avancé — un signal l'y ramène. "en_attente" n'y figure pas : c'est
// l'état de départ, jamais une transition à notifier.
const MESSAGES_STATUT_AIDE = {
  en_examen: {
    titre: "Demande en cours d'examen",
    message: "Votre demande d'aide est en cours d'examen par le Bureau.",
  },
  validee: {
    titre: "Demande d'aide validée",
    message: "Votre demande a été acceptée. Le versement sera effectué prochainement.",
  },
  payee: {
    titre: "Aide versée",
    message: "Le versement de votre aide a été effectué.",
  },
  rejetee: {
    titre: "Demande d'aide rejetée",
    message: "Votre demande n'a pas pu être retenue.",
  },
};

function AidesAdminPage() {
  const { params } = useParametrage();
  const [aides, setAides] = useState([]);
  const [membres, setMembres] = useState({});
  const [bareme, setBareme] = useState({});
  const [controles, setControles] = useState({});
  const [decision, setDecision] = useState(null);
  const [enregistre, setEnregistre] = useState(false);
  const [erreur, setErreur] = useState("");
  const [loading, setLoading] = useState(true);

  async function charger() {
    const [aidesRes, membresRes, baremeRes] = await Promise.all([
      supabase.from("aides_sociales").select("*")
        .eq("organisation_id", params.organisation_id)
        .order("created_at", { ascending: false }),
      supabase.from("membres").select("id, nom")
        .eq("organisation_id", params.organisation_id),
      supabase.from("bareme_prestations").select("*")
        .eq("organisation_id", params.organisation_id),
    ]);

    const listeAides = aidesRes.data || [];

    const mapMembres = {};
    (membresRes.data || []).forEach((x) => { mapMembres[x.id] = x; });

    const mapBareme = {};
    (baremeRes.data || []).forEach((b) => { mapBareme[b.type_aide] = b; });

    setAides(listeAides);
    setMembres(mapMembres);
    setBareme(mapBareme);
    setLoading(false);

    // Contrôle de conformité, limité aux dossiers encore ouverts
    const aInstruire = listeAides.filter(
      (a) => a.statut === "en_attente" || a.statut === "en_examen"
    );

    const resultats = await Promise.all(
      aInstruire.map((a) =>
        supabase
          .rpc("verifier_eligibilite_prestation", {
            p_membre_id: a.membre_id,
            p_type_aide: a.type_aide,
            p_date: String(a.created_at).slice(0, 10),
          })
          .then(({ data }) => ({ id: a.id, resultat: data?.[0] || null }))
      )
    );

    const mapControles = {};
    resultats.forEach((r) => { mapControles[r.id] = r.resultat; });
    setControles(mapControles);
  }

  useEffect(() => { charger(); }, []);

  function choisirStatut(aide, statut) {
    setErreur("");

    if (statut === "validee" || statut === "payee" || statut === "rejetee") {
      const prevu = controles[aide.id]?.montant_prevu
        ?? bareme[aide.type_aide]?.montant_membre
        ?? aide.montant_demande
        ?? 0;

      setDecision({
        id: aide.id,
        statut,
        montant: statut === "rejetee" ? "" : String(prevu || ""),
        motif: "",
      });
      return;
    }

    enregistrerStatut(aide.id, statut, {});
  }

  async function enregistrerStatut(id, statut, complements) {
    setEnregistre(true);
    setErreur("");

    const maj = {
      statut,
      decide_le: new Date().toISOString(),
      ...complements,
    };

    const cible = aides.find((a) => a.id === id);

    const { error } = await supabase.from("aides_sociales").update(maj).eq("id", id);

    setEnregistre(false);

    if (error) { setErreur(error.message); return; }

    setAides((liste) => liste.map((x) => (x.id === id ? { ...x, ...maj } : x)));
    setDecision(null);

    // Traçabilité : tout changement de statut, et séparément le montant
    // lorsqu'il est arrêté à la validation
    consigner(EVENEMENTS.AIDE_STATUT_MODIFIE, {
      membre_id: cible?.membre_id,
      organisation_id: cible?.organisation_id,
      aide_id: id,
      statut,
    });
    if (complements.montant_valide) {
      consigner(EVENEMENTS.AIDE_MONTANT_VALIDE, {
        membre_id: cible?.membre_id,
        organisation_id: cible?.organisation_id,
        aide_id: id,
        montant: complements.montant_valide,
      });
    }

    // Sans ceci, le membre n'a aucun moyen de savoir que sa demande a
    // avancé sans revenir vérifier lui-même — voir MESSAGES_STATUT_AIDE
    // ci-dessus. Échec non bloquant : une notification manquée ne doit
    // jamais remettre en cause une décision déjà enregistrée.
    const infoStatut = MESSAGES_STATUT_AIDE[statut];
    if (infoStatut && cible?.membre_id) {
      notifierMembre(cible.membre_id, {
        type: "aide",
        titre: infoStatut.titre,
        message: complements.motif_rejet
          ? `${infoStatut.message} Motif : ${complements.motif_rejet}`
          : infoStatut.message,
        url: "/",
        organisationId: cible.organisation_id,
      }).catch((e) => console.error("[AidesAdminPage] notifierMembre a échoué :", e));
    }
  }

  function confirmerDecision() {
    if (decision.statut === "rejetee") {
      if (!decision.motif.trim()) {
        setErreur("Indiquez le motif du rejet, il sera visible par le membre.");
        return;
      }
      enregistrerStatut(decision.id, decision.statut, {
        motif_rejet: decision.motif.trim(),
      });
      return;
    }

    enregistrerStatut(decision.id, decision.statut, {
      montant_valide: parseInt(decision.montant, 10) || 0,
    });
  }

  if (loading) {
    return <div style={{ padding: 28, color: C.textSubtle }}>Chargement…</div>;
  }

  return (
    <div style={{ padding: 28 }}>
      {erreur && (
        <div style={{
          background: C.dangerSoft, color: C.danger,
          border: `1px solid ${C.danger}33`, borderRadius: R.md,
          padding: "12px 15px", fontSize: 13.5, marginBottom: 16,
          fontFamily: "'Inter', system-ui, sans-serif",
        }}>
          {erreur}
        </div>
      )}

      {aides.length === 0 ? (
        <div style={carteVide}>Aucune demande d'aide pour le moment.</div>
      ) : (
        <div style={carteListe}>
          {aides.map((a, i) => {
            const ligne = bareme[a.type_aide];
            const controle = controles[a.id];
            const ouvert = a.statut === "en_attente" || a.statut === "en_examen";
            const enDecision = decision?.id === a.id;

            const montantPrevu = controle?.montant_prevu
              ?? ligne?.montant_membre
              ?? null;

            return (
              <div
                key={a.id}
                style={{
                  padding: "18px 20px",
                  borderBottom: i < aides.length - 1 ? `1px solid ${C.border}` : "none",
                }}
              >
                <div style={{
                  display: "flex", justifyContent: "space-between",
                  alignItems: "flex-start", gap: 16, flexWrap: "wrap",
                }}>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 15 }}>
                      {membres[a.membre_id]?.nom || "—"}
                    </div>

                    <div style={{ fontSize: 13, color: C.textSubtle, marginTop: 3 }}>
                      {ligne ? ligne.libelle : a.type_aide}
                      {ligne?.article ? ` · ${ligne.article}` : ""}
                      {" · "}
                      {new Date(a.created_at).toLocaleDateString("fr-FR")}
                    </div>

                    {ligne && ligne.actif === false && (
                      <div style={{ ...encart, background: C.warningSoft, color: "#B45309" }}>
                        Catégorie hors règlement intérieur — demande antérieure à la mise
                        en conformité.
                      </div>
                    )}

                    {a.description && (
                      <div style={{
                        fontSize: 13.5, color: C.textMuted,
                        marginTop: 8, lineHeight: 1.5,
                      }}>
                        {a.description}
                      </div>
                    )}

                    {ouvert && controle && (
                      <div style={{
                        ...encart,
                        background: controle.eligible ? C.successSoft : C.dangerSoft,
                        color: controle.eligible ? C.success : C.danger,
                      }}>
                        {controle.eligible ? (
                          <>Conditions remplies au dépôt (articles 18 et 34).</>
                        ) : (
                          <>
                            <strong>Conditions non remplies : </strong>
                            {controle.motif}
                            {controle.periodes_dues?.length > 0 && (
                              <> Cotisations dues : {controle.periodes_dues
                                .map(formatPeriode).join(", ")}.</>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginTop: 10 }}>
                      {montantPrevu !== null && (
                        <span style={{ fontSize: 13.5, color: C.textSubtle }}>
                          Prévu par les textes :{" "}
                          <strong style={{ color: C.text }}>
                            {montant(montantPrevu)} FCFA
                          </strong>
                        </span>
                      )}
                      {ligne?.montant_don > 0 && (
                        <span style={{ fontSize: 13.5, color: C.textSubtle }}>
                          Don à la famille :{" "}
                          <strong style={{ color: C.text }}>
                            {montant(ligne.montant_don)} FCFA
                          </strong>
                        </span>
                      )}
                      {a.montant_valide ? (
                        <span style={{ fontSize: 13.5, color: C.textSubtle }}>
                          Accordé :{" "}
                          <strong style={{ color: C.success }}>
                            {montant(a.montant_valide)} FCFA
                          </strong>
                        </span>
                      ) : null}
                    </div>

                    {a.motif_rejet && (
                      <div style={{ ...encart, background: C.dangerSoft, color: C.danger }}>
                        <strong>Motif du rejet : </strong>{a.motif_rejet}
                      </div>
                    )}
                  </div>

                  <select
                    value={a.statut}
                    onChange={(e) => choisirStatut(a, e.target.value)}
                    disabled={enregistre}
                    style={{
                      border: `1.5px solid ${COULEURS_STATUT[a.statut]}44`,
                      background: COULEURS_STATUT[a.statut] + "11",
                      color: COULEURS_STATUT[a.statut],
                      borderRadius: R.sm, padding: "8px 12px",
                      fontSize: 13, fontWeight: 600, cursor: "pointer",
                      fontFamily: "inherit", outline: "none", flexShrink: 0,
                    }}
                  >
                    {STATUTS_AIDE.map((s) => (
                      <option key={s} value={s}>{LIBELLES_STATUT[s]}</option>
                    ))}
                  </select>
                </div>

                {enDecision && (
                  <div style={panneauDecision}>
                    {decision.statut === "rejetee" ? (
                      <>
                        <label style={etiquette} htmlFor={`motif-${a.id}`}>
                          Motif du rejet — il sera lu par le membre
                        </label>
                        <textarea
                          id={`motif-${a.id}`}
                          rows={3}
                          value={decision.motif}
                          onChange={(e) =>
                            setDecision((d) => ({ ...d, motif: e.target.value }))}
                          placeholder="Expliquez la décision du Bureau…"
                          style={champ}
                        />
                      </>
                    ) : (
                      <>
                        <label style={etiquette} htmlFor={`montant-${a.id}`}>
                          Montant accordé
                          {montantPrevu !== null && (
                            <span style={{ fontWeight: 400, color: C.textSubtle }}>
                              {" "}— {montant(montantPrevu)} FCFA prévus par
                              {ligne?.article ? ` ${ligne.article}` : " les textes"}
                            </span>
                          )}
                        </label>
                        <input
                          id={`montant-${a.id}`}
                          type="number"
                          value={decision.montant}
                          onChange={(e) =>
                            setDecision((d) => ({ ...d, montant: e.target.value }))}
                          style={champ}
                        />
                        {montantPrevu !== null &&
                          parseInt(decision.montant, 10) !== montantPrevu && (
                          <div style={{
                            fontSize: 12.5, color: "#B45309",
                            marginTop: 6, lineHeight: 1.5,
                          }}>
                            Ce montant s'écarte de celui prévu par le règlement intérieur.
                            L'écart devra être justifié devant l'Assemblée Générale.
                          </div>
                        )}
                      </>
                    )}

                    <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
                      <button
                        onClick={() => { setDecision(null); setErreur(""); }}
                        disabled={enregistre}
                        style={boutonSecondaire}
                      >
                        Annuler
                      </button>
                      <button
                        onClick={confirmerDecision}
                        disabled={enregistre}
                        style={boutonPrincipal}
                      >
                        {enregistre ? "Enregistrement…" : "Confirmer"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Styles partagés ---------------- */

const ecranAttente = {
  minHeight: "100vh", display: "flex", alignItems: "center",
  justifyContent: "center", background: C.bg, color: C.textSubtle,
  fontFamily: "'Inter', system-ui, sans-serif", fontSize: 15,
};

const ecranAttenteOrg = {
  minHeight: "100vh", display: "flex", flexDirection: "column",
  alignItems: "center", justifyContent: "center", textAlign: "center",
  background: C.bg, padding: "32px 24px",
  fontFamily: "'Inter', system-ui, sans-serif", color: C.text,
};

const messageAttente = {
  maxWidth: 520, margin: "48px auto", padding: "0 20px",
  textAlign: "center", color: C.textMuted, fontSize: 15, lineHeight: 1.6,
  fontFamily: "'Inter', system-ui, sans-serif",
};

const lienRetour = {
  background: "none", border: "none", color: C.primary,
  fontWeight: 600, fontSize: 14, cursor: "pointer",
  marginBottom: 20, display: "flex", alignItems: "center",
  gap: 6, padding: 0, fontFamily: "'Inter', system-ui, sans-serif",
};

const titrePage = {
  fontSize: 20, fontWeight: 700, color: C.text,
  letterSpacing: "-0.02em", margin: "0 0 16px",
  fontFamily: "'Inter', system-ui, sans-serif",
};

const carteListe = {
  background: C.surface, borderRadius: R.xl,
  border: `1px solid ${C.border}`, overflow: "hidden",
  boxShadow: SHADOW.xs, fontFamily: "'Inter', system-ui, sans-serif",
};

const carteVide = {
  background: C.surface, border: `1px solid ${C.border}`,
  borderRadius: R.xl, padding: 44, textAlign: "center",
  color: C.textSubtle, fontSize: 14, lineHeight: 1.6,
  fontFamily: "'Inter', system-ui, sans-serif",
};

const badge = {
  fontSize: 12, fontWeight: 600, padding: "5px 12px",
  borderRadius: R.pill, flexShrink: 0, whiteSpace: "nowrap",
};

const encart = {
  marginTop: 10, borderRadius: R.md,
  padding: "9px 12px", fontSize: 13, lineHeight: 1.5,
};

const panneauDecision = {
  marginTop: 16, background: C.bg,
  border: `1px solid ${C.border}`, borderRadius: R.md,
  padding: "14px 16px",
};

const etiquette = {
  display: "block", fontSize: 13.5, fontWeight: 600,
  color: C.textMuted, marginBottom: 8,
};

const champ = {
  width: "100%", boxSizing: "border-box", padding: "11px 13px",
  border: `1.5px solid ${C.border}`, borderRadius: R.sm,
  background: C.surface, fontFamily: "inherit", fontSize: 14.5,
  color: C.text, outline: "none", lineHeight: 1.5, resize: "vertical",
};

const boutonPrincipal = {
  flex: 2, background: C.primary, color: "#fff", border: "none",
  borderRadius: R.sm, padding: "11px 18px", cursor: "pointer",
  fontFamily: "inherit", fontSize: 14, fontWeight: 600,
};

const boutonSecondaire = {
  flex: 1, background: C.surface, color: C.textMuted,
  border: `1.5px solid ${C.border}`, borderRadius: R.sm,
  padding: "11px 18px", cursor: "pointer",
  fontFamily: "inherit", fontSize: 14, fontWeight: 600,
};

/* ---------------- Utilitaires ---------------- */

function montant(v) {
  return (v || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

function formatPeriode(periode) {
  const mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
  const [annee, m] = String(periode).split("-");
  const index = parseInt(m, 10) - 1;
  return mois[index] ? `${mois[index]} ${annee}` : periode;
}

// Libellé d'une cotisation : le motif pour une exceptionnelle, le mois
// pour une périodique.
function libelleCotisation(c) {
  return c.type === "exceptionnelle"
    ? `« ${c.motif || "cotisation exceptionnelle"} »`
    : formatPeriode(c.periode);
}

/* ---------------- Racine ---------------- */

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}